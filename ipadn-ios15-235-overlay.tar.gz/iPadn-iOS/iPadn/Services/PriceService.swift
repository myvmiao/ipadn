import Foundation

/// A value used from several threads, one at a time (formatters aren't thread-safe).
final class NSLockedValue<Value>: @unchecked Sendable {
    private let lock = NSLock()
    private var value: Value
    init(_ value: Value) { self.value = value }
    func withLock<T>(_ body: (inout Value) -> T) -> T { lock.lock(); defer { lock.unlock() }; return body(&value) }
}

/// App Store storefronts, for search region customization and price comparison.
enum StoreRegions {
    static let codes = """
    AE AF AG AI AL AM AO AR AT AU AZ BA BB BD BE BF BG BH BJ BM BN BO BR BS BT BW BY BZ CA CD CG CH CI CL CM CN CO \
    CR CV CY CZ DE DK DM DO DZ EC EE EG ES FI FJ FM FR GA GB GD GE GH GM GR GT GW GY HK HN HR HU ID IE IL IN IQ \
    IS IT JM JO JP KE KG KH KN KR KW KY KZ LA LB LC LI LK LR LT LU LV LY MA MD ME MG MK ML MM MN MO MR MS MT MU MV \
    MW MX MY MZ NA NE NG NI NL NO NP NR NZ OM PA PE PG PH PK PL PT PW PY QA RO RS RU RW SA SB SC SE SG SI SK SL \
    SN SR ST SV SZ TC TD TH TJ TM TN TO TR TT TW TZ UA UG US UY UZ VC VE VG VN VU XK YE ZA ZM ZW
    """.split(separator: " ").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    static let defaultComparison = ["CN", "HK", "US", "JP", "KR", "TR", "NG"]
    static let defaultSearchRegions = ["CN", "US", "HK", "TW", "JP", "GB", "SG", "CA", "AU", "KR", "DE", "FR"]

    /// A storefront's name in the interface language, cached per language.
    static func name(_ code: String, locale: Locale = AppText.locale) -> String { names(locale)[code] ?? code }
    /// All storefronts in the order of their names in the interface language.
    static func byName(_ locale: Locale = AppText.locale) -> [String] {
        codes.sorted { name($0, locale: locale).localizedStandardCompare(name($1, locale: locale)) == .orderedAscending }
    }
    /// Matches a region against a user query across its localized name, English name, and ISO-2 code.
    static func matches(_ code: String, query: String, locale: Locale = AppText.locale) -> Bool {
        matchRank(code, query: query, locale: locale) != nil
    }
    /// Lower rank sorts earlier: 0 = exact ISO-2 code match, 1 = localized/English prefix, 2 = substring.
    static func matchRank(_ code: String, query: String, locale: Locale = AppText.locale) -> Int? {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return 0 }
        let upper = trimmed.uppercased()
        if code.uppercased() == upper { return 0 }
        let localName = name(code, locale: locale)
        let enName = name(code, locale: englishLocale)
        if localName.localizedCaseInsensitiveCompare(trimmed) == .orderedSame
            || enName.localizedCaseInsensitiveCompare(trimmed) == .orderedSame {
            return 0
        }
        if localName.lowercased().hasPrefix(trimmed.lowercased())
            || enName.lowercased().hasPrefix(trimmed.lowercased())
            || code.uppercased().hasPrefix(upper) {
            return 1
        }
        if localName.localizedStandardContains(trimmed)
            || enName.localizedStandardContains(trimmed)
            || code.localizedCaseInsensitiveContains(trimmed) {
            return 2
        }
        return nil
    }
    private static let englishLocale = Locale(identifier: "en_US")
    private static func names(_ locale: Locale) -> [String: String] {
        let key = locale.identifier
        return cachedNames.withLock { cache in
            if let done = cache[key] { return done }
            let localizer = Locale(identifier: key)
            let done = Dictionary(uniqueKeysWithValues: codes.map { ($0, localizer.localizedString(forRegionCode: $0) ?? $0) })
            cache[key] = done
            return done
        }
    }
    private static let cachedNames = NSLockedValue([String: [String: String]]())
    static func flag(_ code: String) -> String {
        code.uppercased().unicodeScalars.compactMap { UnicodeScalar(127_397 + $0.value) }.map(String.init).joined()
    }
    /// Storefronts whose prices leave out sales tax, which is added at checkout.
    static let taxExcluded: Set<String> = ["US", "CA"]
}

/// Daily reference rates (mid-market, before card fees).
struct ExchangeRates: Codable, Equatable {
    var base: String
    /// Units of each currency per one unit of `base`.
    var rates: [String: Double]
    var updated: Date
    var fetched: Date

    /// `amount` in `currency`, expressed in the base currency.
    func convert(_ amount: Double, from currency: String) -> Double? {
        if currency == base { return amount }
        guard let rate = rates[currency], rate > 0 else { return nil }
        return amount / rate
    }

    static func parse(_ data: Data, base: String, fetched: Date = Date()) -> ExchangeRates? {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              (json["result"] as? String) == "success",
              let raw = json["rates"] as? [String: Any] else { return nil }
        var rates: [String: Double] = [:]
        for (code, value) in raw { if let number = value as? NSNumber { rates[code] = number.doubleValue } }
        guard !rates.isEmpty else { return nil }
        let updated = (json["time_last_update_unix"] as? NSNumber).map { Date(timeIntervalSince1970: $0.doubleValue) } ?? fetched
        return ExchangeRates(base: (json["base_code"] as? String) ?? base, rates: rates, updated: updated, fetched: fetched)
    }

    private static let cacheFile = "exchange-rates.json"
    /// Cached rates when recent, else fresh ones; stale cached rates when offline.
    static func load(base: String) async -> ExchangeRates? {
        let stored = try? LocalResources.loadChecked(ExchangeRates.self, filename: cacheFile)
        let cached = stored?.base == base ? stored : nil
        if let cached, Date().timeIntervalSince(cached.fetched) < 12 * 3600 { return cached }
        guard let url = URL(string: "https://open.er-api.com/v6/latest/" + base),
              let result = try? await URLSession.shared.data(from: url),
              (result.1 as? HTTPURLResponse)?.statusCode == 200,
              let fresh = parse(result.0, base: base) else { return cached }
        try? LocalResources.save(fresh, filename: cacheFile)
        return fresh
    }
}

/// One storefront's price for an app.
struct RegionPrice: Identifiable, Equatable {
    var country: String
    var listing: StoreApp?
    var id: String { country }
    var price: Double? { listing?.priceValue }
    var currency: String { listing?.currency ?? "" }
}

enum PriceComparison {
    /// The app's listing in each storefront, a few at a time.
    static func regionPrices(appID: String, countries: [String]) async -> [RegionPrice] {
        var results: [String: RegionPrice] = [:]
        await withTaskGroup(of: RegionPrice?.self) { group in
            var pending = countries.makeIterator()
            for _ in 0..<6 {
                if let country = pending.next() { group.addTask { await regionPrice(appID: appID, country: country) } }
            }
            while let result = await group.next() {
                if let result { results[result.country] = result }
                if let country = pending.next() { group.addTask { await regionPrice(appID: appID, country: country) } }
            }
        }
        var seenCountries = Set<String>()
        let uniqueCountries = countries.filter { seenCountries.insert($0).inserted }
        return uniqueCountries.compactMap { results[$0] }
    }

    /// Nil when the request failed, rather than showing "not listed".
    private static func regionPrice(appID: String, country: String) async -> RegionPrice? {
        guard let found = try? await StoreService.lookup(ids: [appID], country: country) else { return nil }
        return RegionPrice(country: country, listing: found.apps[appID])
    }

    /// Cheapest first in the base currency; unconvertible prices after
    /// those, then storefronts that don't list the app.
    static func sorted(_ prices: [RegionPrice], rates: ExchangeRates?) -> [RegionPrice] {
        func key(_ item: RegionPrice) -> (Int, Double) {
            guard let price = item.price else { return (2, 0) }
            if let converted = rates?.convert(price, from: item.currency) { return (0, converted) }
            return (1, 0)
        }
        return prices.enumerated().sorted { a, b in
            let ka = key(a.element), kb = key(b.element)
            return ka.0 != kb.0 ? ka.0 < kb.0 : ka.1 != kb.1 ? ka.1 < kb.1 : a.offset < b.offset
        }.map(\.element)
    }
}

/// An in-app purchase as an App Store product page lists it.
struct InAppPrice: Hashable {
    var name: String
    /// The page's text, e.g. "$4.99" or "199,99 TL".
    var text: String
    var price: Double?
}

/// The same in-app purchase across storefronts. Items share a name when the
/// app sells several tiers (monthly, yearly): those are told apart by price
/// order, cheapest first.
struct InAppGroup: Identifiable, Equatable {
    struct Entry: Equatable {
        var country: String
        var item: InAppPrice
        var currency: String
    }
    var name: String
    var tier: Int
    var tiers: Int
    var entries: [Entry]
    var id: String { name + "#\(tier)" }
}

enum InAppPriceService {
    /// The in-app purchases a product page lists (Apple shows up to ten),
    /// [] when it lists none, nil when the page could not be read.
    static func fetch(appID: String, country: String) async -> [InAppPrice]? {
        var outcome = await page(appID: appID, country: country)
        if case .failure(let reason) = outcome, !reason.isRedirect {
            // One retry: a busy storefront page often answers the second time.
            try? await compatSleep(seconds: Double(1))
            outcome = await page(appID: appID, country: country)
        }
        let redirected: Bool
        if case .failure(let reason) = outcome { redirected = reason.isRedirect } else { redirected = false }
        await MainActor.run {
            let key = appID + "|" + country.uppercased()
            if redirected { self.redirected.insert(key) } else { self.redirected.remove(key) }
        }
        if case .success(let items) = outcome { return items }
        return nil
    }

    enum PageFailure: Error {
        case network, status(Int), noData, notJSON, redirected
        var isRedirect: Bool { if case .redirected = self { return true }; return false }
    }
    /// Storefront pages this network is sent away from (appID|COUNTRY).
    /// From mainland China, apps.apple.com redirects other storefronts'
    /// product pages to the China store's Today page.
    @MainActor static var redirected: Set<String> = []

    /// The product page as a desktop browser gets it, following redirects.
    /// Pages are read in English by default (Apple picks its closest English
    /// page in every storefront), so the same purchase has the same name everywhere.
    static func page(appID: String, country: String, language: String = "en-US") async -> Result<[InAppPrice], PageFailure> {
        switch await fetchPage(appID: appID, country: country, language: language) {
        case .failure(let reason): return .failure(reason)
        case .success(let html):
            guard let items = items(fromPage: html) else { return .failure(.notJSON) }
            return .success(items)
        }
    }

    /// A storefront's product page in `language`, as long as the network
    /// isn't sent to another storefront and the page carries its data.
    static func fetchPage(appID: String, country: String, language: String) async -> Result<String, PageFailure> {
        guard let url = URL(string: "https://apps.apple.com/\(country.lowercased())/app/id\(appID)?l=\(language)") else { return .failure(.status(0)) }
        var request = URLRequest(url: url, timeoutInterval: 30)
        request.setValue(browserAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("text/html", forHTTPHeaderField: "Accept")
        request.setValue(language + ",en;q=0.5", forHTTPHeaderField: "Accept-Language")
        let data: Data
        let landed: URL?
        do {
            let (body, response) = try await pageSession.data(for: request)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard (200..<300).contains(code) else { return .failure(.status(code)) }
            data = body; landed = response.url
        } catch { return .failure(.network) }
        if let landed, !landed.path.lowercased().hasPrefix("/\(country.lowercased())/") || !landed.path.contains("/app/") {
            return .failure(.redirected)
        }
        let html = String(decoding: data, as: UTF8.self)
        guard html.contains("serialized-server-data") else { return .failure(.noData) }
        return .success(html)
    }

    private static let pageSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForResource = 60
        config.httpCookieStorage = nil
        return URLSession(configuration: config)
    }()
    /// Several storefronts, a few pages at a time, kept for an hour.
    @MainActor
    static func fetch(appID: String, countries: [String]) async -> [String: [InAppPrice]] {
        var results: [String: [InAppPrice]] = [:]
        var missing: [String] = []
        for country in countries {
            if let cached = cache[appID + "|" + country], Date().timeIntervalSince(cached.date) < 3600 { results[country] = cached.items }
            else { missing.append(country) }
        }
        await withTaskGroup(of: (String, [InAppPrice]?).self) { group in
            var pending = missing.makeIterator()
            for _ in 0..<3 {
                if let country = pending.next() { group.addTask { (country, await fetch(appID: appID, country: country)) } }
            }
            while let result = await group.next() {
                let (country, items) = result
                if let items { results[country] = items; cache[appID + "|" + country] = (Date(), items) }
                if let country = pending.next() { group.addTask { (country, await fetch(appID: appID, country: country)) } }
            }
        }
        return results
    }
    @MainActor private static var cache: [String: (date: Date, items: [InAppPrice])] = [:]

    /// Names in the system language for the English names in `english`, read
    /// from one storefront's page in that language. Empty when the system
    /// language is English or no page could be matched.
    @MainActor
    static func localizedNames(appID: String, english: [String: [InAppPrice]],
                               language: String = Locale.preferredLanguages.first ?? "en") async -> [String: String] {
        guard !language.lowercased().hasPrefix("en") else { return [:] }
        let key = appID + "|" + language
        if let cached = nameCache[key], Date().timeIntervalSince(cached.date) < 3600 { return cached.names }
        // Storefronts that list names in the language first, then the other
        // storefronts that were read.
        var candidates: [String] = []
        for code in nameRegions(language: language) + [Locale.current.regionCode?.uppercased()].compactMap({ $0 }) + english.keys.sorted()
        where !candidates.contains(code) && english[code]?.isEmpty == false {
            candidates.append(code)
        }
        for country in candidates.prefix(2) {
            guard case .success(let localized) = await page(appID: appID, country: country, language: language),
                  let reference = english[country] else { continue }
            let names = nameMap(english: reference, localized: localized)
            if !names.isEmpty {
                nameCache[key] = (Date(), names)
                return names
            }
        }
        return [:]
    }
    @MainActor private static var nameCache: [String: (date: Date, names: [String: String])] = [:]

    /// Storefronts whose pages are written in a language, first the one in
    /// the language tag's region when it is one of them (PT for pt-PT), then
    /// the language's main storefront (JP for ja, even on a ja-CN device).
    static func nameRegions(language: String) -> [String] {
        let tag = language.lowercased()
        let tagRegion = Locale(identifier: language).regionCode?.uppercased()
        let native: [String]
        switch tag {
        case _ where tag.hasPrefix("zh-hans"): native = ["CN"]
        case _ where tag.hasPrefix("zh-hant"), _ where tag.hasPrefix("zh-hk"), _ where tag.hasPrefix("zh-tw"): native = ["TW", "HK", "MO"]
        case _ where tag.hasPrefix("ja"): native = ["JP"]
        case _ where tag.hasPrefix("ko"): native = ["KR"]
        case _ where tag.hasPrefix("ru"): native = ["RU", "BY", "KZ"]
        case _ where tag.hasPrefix("es"): native = ["ES", "MX", "AR", "CO", "CL", "PE"]
        case _ where tag.hasPrefix("fr"): native = ["FR", "CA", "BE", "CH"]
        case _ where tag.hasPrefix("de"): native = ["DE", "AT", "CH"]
        case _ where tag.hasPrefix("pt"): native = ["BR", "PT"]
        case _ where tag.hasPrefix("ar"): native = ["SA", "AE", "EG", "KW", "QA", "JO", "MA"]
        default: return [tagRegion].compactMap { $0 }
        }
        if let tagRegion, native.contains(tagRegion) { return [tagRegion] + native.filter { $0 != tagRegion } }
        return native
    }

    /// One storefront lists its purchases in the same order and at the same
    /// prices in every language, so its two lists pair up item by item. Any
    /// difference means the lists can't be paired: no names then.
    static func nameMap(english: [InAppPrice], localized: [InAppPrice]) -> [String: String] {
        guard english.count == localized.count, !english.isEmpty else { return [:] }
        var names: [String: String] = [:]
        for (en, local) in zip(english, localized) {
            guard en.price == local.price else { return [:] }
            if names[en.name] == nil { names[en.name] = local.name }
        }
        // Nothing to show if the "localized" page came back in English too.
        return names.contains { $0.key != $0.value } ? names : [:]
    }

    // The desktop page carries the information section with in-app purchases.
    static let browserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"

    static func serializedData(_ html: String) -> Any? {
        guard let marker = html.range(of: "id=\"serialized-server-data\""),
              let open = html[marker.upperBound...].firstIndex(of: ">"),
              let close = html.range(of: "</script>", range: html.index(after: open)..<html.endIndex)
        else { return nil }
        return try? JSONSerialization.jsonObject(with: Data(html[html.index(after: open)..<close.lowerBound].utf8))
    }

    static func items(fromPage html: String) -> [InAppPrice]? {
        guard let json = serializedData(html) else { return nil }
        // The information section is a list of annotations; the in-app
        // purchase one pairs item names with prices. Its title depends on the
        // page language, so it is recognised by its contents.
        var best: [InAppPrice] = []
        func visit(_ value: Any, depth: Int) {
            guard depth < 40 else { return }
            if let dict = value as? [String: Any] {
                if dict["$kind"] as? String == "Annotation", let entries = dict["items"] as? [[String: Any]] {
                    let pairs = entries.filter { $0["$kind"] as? String == "textPair" }
                    let found = pairs.compactMap { pair -> InAppPrice? in
                        guard let name = pair["leadingText"] as? String, let text = pair["trailingText"] as? String,
                              looksLikePrice(text) else { return nil }
                        return InAppPrice(name: name, text: text, price: price(text))
                    }
                    if !pairs.isEmpty, found.count == pairs.count, found.count > best.count { best = found }
                }
                for child in dict.values { visit(child, depth: depth + 1) }
            } else if let array = value as? [Any] {
                for child in array { visit(child, depth: depth + 1) }
            }
        }
        visit(json, depth: 0)
        // Some apps list the same purchase twice (one per platform).
        var seen = Set<InAppPrice>()
        return best.filter { seen.insert($0).inserted }
    }

    /// A short amount with at most a currency sign or code around it.
    static func looksLikePrice(_ text: String) -> Bool {
        guard text.count <= 24, text.contains(where: \.isNumber) else { return false }
        let ignored: Set<Character> = [".", ",", "'", " ", "\u{00A0}", "\u{202F}"]
        let rest = text.filter { !$0.isNumber && !ignored.contains($0) }
        return rest.count <= 4
    }

    /// The number in a formatted price, whatever the separators:
    /// "$1,099" → 1099, "1.299,99 €" → 1299.99, "Rp 15.000" → 15000.
    static func price(_ text: String) -> Double? {
        let digits = text.filter { $0.isNumber || $0 == "." || $0 == "," }
        guard !digits.isEmpty else { return nil }
        let separators = digits.enumerated().filter { $0.element == "." || $0.element == "," }
        var normalized = digits
        if let last = separators.last {
            let decimals = digits.count - last.offset - 1
            let lastIsDecimal: Bool
            if Set(separators.map(\.element)).count > 1 { lastIsDecimal = true }
            else { lastIsDecimal = separators.count == 1 && decimals != 3 }
            var chars = Array(digits)
            for (offset, _) in separators { chars[offset] = offset == last.offset && lastIsDecimal ? "." : "_" }
            normalized = String(chars.filter { $0 != "_" })
        }
        return Double(normalized)
    }

    /// Groups each storefront's items into comparable purchases, in the order
    /// the first storefront lists them, cheapest storefront first in each.
    static func groups(_ regions: [(country: String, currency: String, items: [InAppPrice])],
                       rates: ExchangeRates?) -> [InAppGroup] {
        var order: [String] = []
        var groups: [String: InAppGroup] = [:]
        for region in regions {
            let byName = Dictionary(grouping: region.items, by: \.name)
            for item in region.items where byName[item.name]?.first == item {
                let tiers = (byName[item.name] ?? []).sorted { ($0.price ?? .infinity) < ($1.price ?? .infinity) }
                for (tier, tierItem) in tiers.enumerated() {
                    let key = item.name + "#\(tier)"
                    if groups[key] == nil {
                        order.append(key)
                        groups[key] = InAppGroup(name: item.name, tier: tier, tiers: tiers.count, entries: [])
                    }
                    groups[key]!.tiers = max(groups[key]!.tiers, tiers.count)
                    groups[key]!.entries.append(.init(country: region.country, item: tierItem, currency: region.currency))
                }
            }
        }
        return order.compactMap { key in
            guard var group = groups[key] else { return nil }
            group.entries = group.entries.enumerated().sorted { a, b in
                let ca = a.element.item.price.flatMap { rates?.convert($0, from: a.element.currency) }
                let cb = b.element.item.price.flatMap { rates?.convert($0, from: b.element.currency) }
                switch (ca, cb) {
                case let (x?, y?): return x != y ? x < y : a.offset < b.offset
                case (.some, nil): return true
                case (nil, .some): return false
                default: return a.offset < b.offset
                }
            }.map(\.element)
            return group
        }
    }
}

/// One version's entry in a product page's version history.
struct ReleaseNote: Equatable {
    var version: String
    var date: Date?
    var text: String
}

enum ReleaseNotesService {
    /// The version history a product page carries, by version number, in
    /// the system language where the storefront offers it. Tries the
    /// storefronts in order; empty when none could be read.
    @MainActor
    static func notes(appID: String, countries: [String],
                      language: String = Locale.preferredLanguages.first ?? "en-US",
                      force: Bool = false) async -> [String: ReleaseNote] {
        for country in countries {
            let key = appID + "|" + country + "|" + language
            if !force, let cached = cache[key] {
                let age = Date().timeIntervalSince(cached.date)
                if !cached.notes.isEmpty && age < 6 * 3600 { return cached.notes }
                // A page that couldn't be read (or was redirected) isn't retried immediately.
                if cached.notes.isEmpty && age < 60 { continue }
            }
            var notes: [String: ReleaseNote] = [:]
            if case .success(let html) = await InAppPriceService.fetchPage(appID: appID, country: country, language: language) {
                // The page's data runs to megabytes: read it off the main thread.
                notes = await Task.detached(priority: .utility) { parse(html) }.value
            }
            guard !Task.isCancelled else { return [:] }
            cache[key] = (Date(), notes)
            if !notes.isEmpty { return notes }
        }
        return [:]
    }
    @MainActor private static var cache: [String: (date: Date, notes: [String: ReleaseNote])] = [:]

    /// Version history entries: TitledParagraph items whose subtitles hold
    /// "Version 1.2.3" (localized) and the release date.
    static func parse(_ html: String) -> [String: ReleaseNote] {
        guard let json = InAppPriceService.serializedData(html) else { return [:] }
        var notes: [String: ReleaseNote] = [:]
        func visit(_ value: Any, depth: Int) {
            guard depth < 40 else { return }
            if let dict = value as? [String: Any] {
                if dict["$kind"] as? String == "TitledParagraph", let text = dict["text"] as? String,
                   let subtitle = dict["primarySubtitle"] as? String, let number = version(in: subtitle) {
                    // The latest version appears twice (What's New and the history); keep any date either gives.
                    let released = (dict["secondarySubtitle"] as? String).flatMap(date)
                    if var known = notes[number] {
                        if known.date == nil { known.date = released; notes[number] = known }
                    } else {
                        notes[number] = ReleaseNote(version: number, date: released,
                                                     text: text.trimmingCharacters(in: .whitespacesAndNewlines))
                    }
                }
                for child in dict.values { visit(child, depth: depth + 1) }
            } else if let array = value as? [Any] {
                for child in array { visit(child, depth: depth + 1) }
            }
        }
        visit(json, depth: 0)
        return notes
    }

    /// "Version 1.2.3", "版本 1.2.3" → "1.2.3".
    static func version(in subtitle: String) -> String? {
        let token = subtitle.split(whereSeparator: { $0.isWhitespace }).last.map(String.init) ?? subtitle
        let trimmed = token.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.").inverted)
        return trimmed.first?.isNumber == true ? trimmed : nil
    }

    /// "Tue Oct 06 2026 18:07:01 GMT+0000 (Coordinated Universal Time)".
    static func date(_ text: String) -> Date? {
        let core = text.components(separatedBy: " (").first ?? text
        return dateFormatter.withLock { $0.date(from: core) }
    }
    private static let dateFormatter = NSLockedValue({
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "EEE MMM dd yyyy HH:mm:ss 'GMT'Z"
        return formatter
    }())
}
