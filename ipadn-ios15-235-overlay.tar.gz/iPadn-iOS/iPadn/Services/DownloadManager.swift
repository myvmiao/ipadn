import Foundation
import Combine
import Network
import UserNotifications
import UIKit
#if canImport(TestFlightKit)
import TestFlightKit
#endif

/// Progress has its own publisher: a byte counter must not invalidate every list.
@MainActor
final class DownloadProgressState: ObservableObject {
    @Published var bytes: (written: Int64, expected: Int64)?
    func applying(to job: DownloadJob) -> DownloadJob {
        guard let bytes, [.running, .pausing, .paused].contains(job.status) else { return job }
        var result = job
        result.downloaded = bytes.written; result.expected = bytes.expected
        return result
    }
}

@MainActor
final class DownloadManager: NSObject, ObservableObject {
    private final class DeliveryGate: @unchecked Sendable {
        private let lock = NSLock()
        private var count = 0
        func begin() { lock.lock(); count += 1; lock.unlock() }
        func end() { lock.lock(); count -= 1; lock.unlock() }
        var isEmpty: Bool { lock.lock(); defer { lock.unlock() }; return count == 0 }
    }
    nonisolated private let deliveries = DeliveryGate()
    static var sessionID: String {
        (Bundle.main.bundleIdentifier ?? "app.local.iPadn") + ".background.downloads"
    }
    @Published private(set) var jobs: [DownloadJob] = [] { didSet { updateInstallKeepAlive() } }
    @Published var storageError: String?
    @Published private(set) var discoveryWarning: String?
    /// The last save failed (for example, the disk is full); cleared by the next successful save.
    @Published private(set) var saveWarning: String?
    /// Stage text for Mac App Store packages being processed on device.
    @Published private(set) var processingDetail: [UUID: String] = [:]
    /// Mac tasks the user asked to cancel and that have not stopped yet.
    @Published private(set) var cancelling: Set<UUID> = []
    var backgroundCompletion: (() -> Void)?
    private var tasks: [UUID: URLSessionDownloadTask] = [:]
    private var rowProgress: [UUID: DownloadProgressState] = [:]
    @Published private(set) var removingIDs = Set<UUID>()
    private var loadingJobs = false
    private var startupTask: Task<Void, Never>?
    /// Returns once the saved download list has been read (Shortcuts may
    /// run before the app ever showed it).
    func loaded() async { await startupTask?.value }
    func progress(for id: UUID) -> DownloadProgressState {
        if let progress = rowProgress[id] { return progress }
        let progress = DownloadProgressState(); rowProgress[id] = progress
        return progress
    }
    private var currentJobs: [DownloadJob] { jobs.map { rowProgress[$0.id]?.applying(to: $0) ?? $0 } }
    private func accepts(_ task: URLSessionTask, id: UUID, restoredDelivery: Bool = false) -> Bool {
        guard !removingIDs.contains(id) else { return false }
        if let current = tasks[id] { return current === task }
        return restoring || restoredDelivery
    }
    private var restoring = true
    private var maxConcurrent = 3
    private var maxQueued = 10
    private var processingIDs = Set<UUID>()
    private var iconsLoading = false
    private var catalogArtworkAttempted = Set<UUID>()
    private var iconSizeChecked = Set<UUID>()
    private var olderIconRetried = Set<UUID>()
    private var packageIconCache: [UUID: Bool] = [:]
    private var removalAfterCancel = Set<UUID>()
    private let persistQueue = DispatchQueue(label: "iPadn.download-jobs", qos: .utility)
    private var artworkCountry = "CN"
    private var notifications = true
    private var compatibleDownloadMode = false
    private var fallbackForegroundIDs = Set<UUID>()
    /// Settings: download only over Wi-Fi; install each finished download.
    private var wifiOnly = false
    private var autoInstall = false
    private var pathMonitor: NWPathMonitor?
    /// The network in use is cellular (no Wi-Fi or wired connection).
    private var onCellular = false
    /// "Download Anyway" until Wi-Fi is back.
    private var cellularAllowed = false
    /// Downloads wait for Wi-Fi: the setting is on and only cellular is available.
    @Published private(set) var waitingForWiFi = false
    /// External completed package (such as a TestFlight build) handed into the same
    /// automatic-install pipeline (silent native install or install sheet).
    struct ExternalAutoInstallTarget: Identifiable {
        let id: UUID
        let job: DownloadJob
        let fileURL: URL
        let iconURL: URL?
        let isTestFlight: Bool
        let onInstalled: (@MainActor () -> Void)?
    }

    /// Finished downloads waiting for the install sheet to open.
    @Published var pendingAutoInstalls: [UUID] = []
    /// Finished external downloads (e.g. TestFlight) waiting for the install sheet to open.
    @Published var pendingExternalAutoInstalls: [ExternalAutoInstallTarget] = []
    /// Install When Downloaded with native installation: no prompt is needed,
    /// so finished downloads install by themselves, also in the background.
    private var silentInstall = false
    private var downloadLiveActivityEnabled = false
    private var silentQueue: [UUID] = []
    private var externalSilentTargets: [UUID: ExternalAutoInstallTarget] = [:]
    private var silentInstallTask: Task<Void, Never>?
    private var activeSilentAttemptTask: Task<NativeInstaller.Outcome, Error>?
    private var silentCancelledIDs = Set<UUID>()
    private var silentRunning = false { didSet { updateInstallKeepAlive() } }
    @Published private(set) var isLoaded = false
    /// iOS suspends iPadn soon after it leaves the screen, which would stop
    /// silent installs and freeze the Dynamic Island percentage until iPadn
    /// is opened again. Keep running while a Live Activity download or silent
    /// auto-install is actively in progress.
    private let installKeepAlive = BackgroundKeepAlive(name: "iPadn auto install")
    private var keepingAlive = false
    func syncTestFlightKeepAlive() {
        updateInstallKeepAlive()
    }
    func syncLiveActivityKeepAlive() {
        updateInstallKeepAlive()
    }
    private func updateInstallKeepAlive() {
        #if canImport(TestFlightKit)
        let tfBusy = TFHomeModel.shared.hasBusyDownloads
        let tfAutoInstallBusy = silentInstall && tfBusy
        let tfForegroundBusy = TFHomeModel.shared.needsForegroundBackgroundKeepAlive
        #else
        let tfBusy = false
        let tfAutoInstallBusy = false
        let tfForegroundBusy = false
        #endif
        let hasActiveRegularDownload = jobs.contains { [.running, .processing].contains($0.status) }
        let liveActivityBusy = downloadLiveActivityEnabled
            && DownloadActivity.shared.hasActiveActivity
            && (hasActiveRegularDownload || tfBusy)
        let busy = liveActivityBusy || tfAutoInstallBusy || tfForegroundBusy || (silentInstall && (silentRunning || !silentQueue.isEmpty || !externalSilentTargets.isEmpty || jobs.contains { job in
            [.running, .queued, .processing].contains(job.status)
                && job.rawFormat == nil && job.protectedMacPackage != true && job.asset != nil
        }))
        guard busy != keepingAlive else { return }
        keepingAlive = busy
        InstallLog.shared.add(busy ? "keeping iPadn running for background download/install" : "background download/install keep-alive ended")
        if busy { installKeepAlive.start() } else { installKeepAlive.stop() }
    }
    /// A line for iPadn's top notice while it is open (notifications only
    /// appear in the background).
    @Published var autoInstallNotice: String?
    enum AutoInstallStage: Int, Equatable, Sendable { case connecting, uploading, installing }
    /// The automatic installation in progress, for the Live Activity and downloads banner.
    struct AutoInstallProgress: Equatable {
        var id: UUID
        var name: String
        var fraction: Double
        var canCancel: Bool = true
        var stage: AutoInstallStage = .connecting
        var hasProgress: Bool { stage != .connecting && fraction >= 0.005 }
    }
    enum AutoInstallCancelOutcome: Equatable { case idle, cancelled, irreversible }
    @Published private(set) var autoInstalling: AutoInstallProgress?
    #if DEBUG
    func setAutoInstallingForTesting(_ progress: AutoInstallProgress?) { autoInstalling = progress }
    func setWaitingAutoInstallForTesting(_ id: UUID, waiting: Bool) { markWaiting(id, waiting) }
    func setInFlightAutoInstallForTesting(_ id: UUID?) { inFlightAutoInstallID = id?.uuidString }
    func recoverInterruptedAutoInstallForTesting() { recoverInterruptedAutoInstall() }
    #endif
    /// The app just installed automatically (Live Activity "Installed").
    @Published private(set) var autoInstalled: String?
    /// The automatic installation that did not finish (Live Activity "Not installed").
    @Published private(set) var autoInstallFailed: String?
    /// The automatic installation stopped by the user so the Live Activity dismisses cleanly.
    @Published private(set) var autoInstallCancelled: String?
    /// A finished download about to be installed silently.
    func waitsForSilentInstall(_ id: UUID) -> Bool { silentInstall && waitingInstalls.contains(id.uuidString) }
    /// Finished downloads still waiting to be installed automatically. Kept
    /// across launches: iOS can end iPadn in the background mid-install.
    private static let autoInstallKey = "autoInstallWaiting"
    private static let autoInstallInFlightKey = "autoInstallInFlight"
    private var waitingInstalls: [String] {
        get { LocalResources.defaults.stringArray(forKey: Self.autoInstallKey) ?? [] }
        set { LocalResources.defaults.set(newValue, forKey: Self.autoInstallKey) }
    }
    private var inFlightAutoInstallID: String? {
        get { LocalResources.defaults.string(forKey: Self.autoInstallInFlightKey) }
        set {
            if let newValue { LocalResources.defaults.set(newValue, forKey: Self.autoInstallInFlightKey) }
            else { LocalResources.defaults.removeObject(forKey: Self.autoInstallInFlightKey) }
        }
    }
    private func markWaiting(_ id: UUID, _ waiting: Bool) {
        var list = waitingInstalls.filter { $0 != id.uuidString }
        if waiting { list.append(id.uuidString) }
        waitingInstalls = list
    }

    /// iPadn is in front: install what is still waiting, silently with
    /// native installation, otherwise through the install sheet.
    func resumeAutoInstalls() {
        Task { @MainActor in
            await loaded()
            resumeWaitingInstalls()
        }
    }
    private func resumeWaitingInstalls() {
        guard autoInstall else { waitingInstalls = []; return }
        for value in waitingInstalls {
            guard let id = UUID(uuidString: value), jobs.contains(where: { $0.id == id && $0.status == .completed }) else {
                if let id = UUID(uuidString: value) { markWaiting(id, false) } else { waitingInstalls = waitingInstalls.filter { $0 != value } }
                continue
            }
            if silentInstall { installSilently(id) }
            else {
                // Other install methods ask once; cancelling that sheet is the answer.
                markWaiting(id, false)
                if !pendingAutoInstalls.contains(id) { pendingAutoInstalls.append(id) }
            }
        }
    }
    /// The system download service could not write into iPadn's container
    /// (seen with some re-signed builds). Kept per app build: a new install
    /// or signature may behave differently, so it is checked again then.
    @Published private(set) var backgroundDownloadsUnavailable = DownloadManager.loadBackgroundUnavailable()
    private static let backgroundUnavailableKey = "backgroundDownloadsUnavailableBuild"
    private static var currentBuild: String {
        let info = Bundle.main.infoDictionary
        return "\(info?["CFBundleShortVersionString"] as? String ?? "")-\(info?["CFBundleVersion"] as? String ?? "")-\(Bundle.main.bundlePath)"
    }
    private static func loadBackgroundUnavailable() -> Bool {
        UserDefaults.standard.string(forKey: backgroundUnavailableKey) == currentBuild
    }
    /// Lets the next download try the system download service again.
    func retryBackgroundDownloads() {
        UserDefaults.standard.removeObject(forKey: Self.backgroundUnavailableKey)
        UserDefaults.standard.removeObject(forKey: Self.backgroundProbedKey)
        backgroundDownloadsUnavailable = false
        #if canImport(TestFlightKit)
        TFTransfer.preferForegroundSession = compatibleDownloadMode
        #endif
        startBackgroundProbeIfNeeded()
    }
    private func markBackgroundUnavailable() {
        guard !backgroundDownloadsUnavailable else { return }
        backgroundDownloadsUnavailable = true
        UserDefaults.standard.set(Self.currentBuild, forKey: Self.backgroundUnavailableKey)
        #if canImport(TestFlightKit)
        TFTransfer.preferForegroundSession = true
        #endif
    }

    // A tiny download through the system download service, once per install:
    // with signatures it cannot write for, it fails the same way a package
    // would, but before the user waits for a whole package to download twice.
    nonisolated static let backgroundProbeDescription = "ipadn.background-probe"
    /// Apple's own 68-byte connectivity page; no third-party host is contacted.
    private static let backgroundProbeURL = URL(string: "https://www.apple.com/library/test/success.html")!
    private static let backgroundProbedKey = "backgroundDownloadsProbedBuild"
    private func startBackgroundProbeIfNeeded() {
        guard !backgroundDownloadsUnavailable, !LocalResources.isPreview,
              ProcessInfo.processInfo.environment["XCTestConfigurationFilePath"] == nil,
              UserDefaults.standard.string(forKey: Self.backgroundProbedKey) != Self.currentBuild else { return }
        let task = session.downloadTask(with: Self.backgroundProbeURL)
        task.taskDescription = Self.backgroundProbeDescription
        task.resume()
    }
    /// The probe's outcome. Only a file-creation failure, or a file iPadn
    /// can't read, says anything; other errors (offline, captive Wi-Fi) leave
    /// it to be tried on a later launch.
    private func finishBackgroundProbe(error: NSError?, unreadable: Bool = false) {
        if unreadable {
            markBackgroundUnavailable()
        } else if let error {
            guard error.domain == NSURLErrorDomain, error.code == NSURLErrorCannotCreateFile else { return }
            markBackgroundUnavailable()
        }
        UserDefaults.standard.set(Self.currentBuild, forKey: Self.backgroundProbedKey)
    }
    /// The system service saved the file where iPadn may not read it (seen
    /// with some re-signed builds): "you don't have permission to view it".
    nonisolated static func isPermissionError(_ error: Error) -> Bool {
        let error = error as NSError
        if error.domain == NSCocoaErrorDomain, [NSFileReadNoPermissionError, NSFileWriteNoPermissionError].contains(error.code) { return true }
        if error.domain == NSPOSIXErrorDomain, [Int(EACCES), Int(EPERM)].contains(error.code) { return true }
        if let underlying = error.userInfo[NSUnderlyingErrorKey] as? Error { return isPermissionError(underlying) }
        return false
    }
    /// Downloads the job again inside the app, once, and keeps later
    /// downloads there for this build.
    private func fallBackToForeground(_ id: UUID) -> Bool {
        guard !fallbackForegroundIDs.contains(id), let index = jobs.firstIndex(where: { $0.id == id }) else { return false }
        fallbackForegroundIDs.insert(id)
        markBackgroundUnavailable()
        tasks.removeValue(forKey: id)
        progressPublishedAt.removeValue(forKey: id)
        updateBackgroundTask()
        try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
        jobs[index].status = .queued
        jobs[index].downloaded = 0
        jobs[index].error = nil
        persist()
        schedule()
        return true
    }
    private var backgroundTaskID: UIBackgroundTaskIdentifier = .invalid
    private var lastSave = Date.distantPast
    private var transferMetrics: [UUID: TransferMetrics] = [:]
    private var progressPublishedAt: [UUID: TimeInterval] = [:]
    private var saveJobs: ([DownloadJob]) throws -> Void = { try LocalResources.save($0, filename: LocalResources.jobsFilename) }
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: Self.sessionID)
        config.isDiscretionary = false
        config.sessionSendsLaunchEvents = true
        config.httpMaximumConnectionsPerHost = 3
        config.timeoutIntervalForRequest = 60
        config.timeoutIntervalForResource = 24 * 3600
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()
    private lazy var foregroundSession: URLSession = {
        let config = URLSessionConfiguration.default
        config.httpMaximumConnectionsPerHost = 3
        config.timeoutIntervalForRequest = 60
        config.timeoutIntervalForResource = 24 * 3600
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    private func activeSession(for id: UUID) -> URLSession {
        if compatibleDownloadMode || backgroundDownloadsUnavailable || fallbackForegroundIDs.contains(id) {
            return foregroundSession
        }
        return session
    }

    private func updateBackgroundTask() {
        let hasActive = tasks.contains { id, _ in
            compatibleDownloadMode || backgroundDownloadsUnavailable || fallbackForegroundIDs.contains(id)
        }
        if hasActive {
            if backgroundTaskID == .invalid {
                backgroundTaskID = UIApplication.shared.beginBackgroundTask(withName: "iPadn.foregroundDownload") { [weak self] in
                    let endNow = {
                        guard let self, self.backgroundTaskID != .invalid else { return }
                        let current = self.backgroundTaskID
                        self.backgroundTaskID = .invalid
                        UIApplication.shared.endBackgroundTask(current)
                    }
                    if Thread.isMainThread {
                        MainActor.assumeIsolated { endNow() }
                    } else {
                        DispatchQueue.main.sync { MainActor.assumeIsolated { endNow() } }
                    }
                }
            }
        } else if backgroundTaskID != .invalid {
            let current = backgroundTaskID
            backgroundTaskID = .invalid
            UIApplication.shared.endBackgroundTask(current)
        }
    }

    #if DEBUG
    init(previewJobs: [DownloadJob], activeTasks: [UUID: URLSessionDownloadTask] = [:], saveJobs: @escaping ([DownloadJob]) throws -> Void = { _ in }) {
        super.init()
        jobs = previewJobs
        self.saveJobs = saveJobs
        isLoaded = true
        // Screenshots never create a URLSession or start real transfers.
        tasks = activeTasks
        restoring = activeTasks.isEmpty
    }
    /// Isolated UI-test fixture: exercise the real row's processing/completed
    /// transitions without a URLSession, file writes, notifications or install.
    func completePreviewDownload(_ id: UUID) {
        guard LocalResources.isPreview,
              ProcessInfo.processInfo.arguments.contains("--completion-preview"),
              let index = jobs.firstIndex(where: { $0.id == id && $0.status == .running }) else { return }
        jobs[index].status = .processing
        Task { @MainActor [weak self] in
            do { try await compatSleep(milliseconds: Double(350)) } catch { return }
            guard let self, let index = self.jobs.firstIndex(where: { $0.id == id && $0.status == .processing }) else { return }
            self.jobs[index].downloaded = self.jobs[index].expected
            self.jobs[index].status = .completed
        }
    }
    #endif

    override init() {
        super.init()
        loadingJobs = true
        // Write the latest progress to disk before the app can be suspended.
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.persist(wait: true) }
        }
        startupTask = Task {
            do {
                jobs = try await Task.detached(priority: .userInitiated) {
                    let saved = try LocalResources.loadChecked([DownloadJob].self, filename: LocalResources.jobsFilename) ?? []
                    try Self.recoverRemovals(saved)
                    return saved
                }.value
            } catch { storageError = AppText.text("任务文件读取失败；已保留原文件，请先导出诊断再处理。") + "\n" + error.localizedDescription }
            loadingJobs = false
            recoverInterruptedAutoInstall()
            await restore()
            isLoaded = true
            startBackgroundProbeIfNeeded()
        }
    }

    /// If the previous launch terminated abnormally while NativeInstaller was
    /// running, prevent an immediate silent auto-install crash loop on relaunch.
    private func recoverInterruptedAutoInstall() {
        guard let rawID = inFlightAutoInstallID else { return }
        inFlightAutoInstallID = nil
        guard let id = UUID(uuidString: rawID) else { return }
        markWaiting(id, false)
        if let job = jobs.first(where: { $0.id == id && $0.status == .completed }) {
            let name = job.userFacingTitle
            autoInstallFailed = name
            autoInstallNotice = AppText.text("上次自动安装未完成，请在下载列表中重试 \(name)")
            InstallLog.shared.add("cleared interrupted silent auto-install on launch: \(name)")
        }
    }

    func configure(_ settings: ToolSettings) {
        maxConcurrent = min(6, max(1, settings.maxConcurrentDownloads))
        maxQueued = max(1, settings.maxQueuedDownloads)
        notifications = settings.notifications
        artworkCountry = settings.store.country
        compatibleDownloadMode = settings.compatibleDownloadMode
        #if canImport(TestFlightKit)
        TFTransfer.preferForegroundSession = compatibleDownloadMode || backgroundDownloadsUnavailable
        #endif
        autoInstall = settings.autoInstall
        silentInstall = settings.autoInstall && settings.usesNativeInstallation
        downloadLiveActivityEnabled = settings.downloadLiveActivity
        if !autoInstall {
            pendingAutoInstalls.removeAll()
            pendingExternalAutoInstalls.removeAll()
            silentQueue.removeAll()
            externalSilentTargets.removeAll()
            waitingInstalls = []
            _ = cancelAutoInstall(nil)
        } else if !silentInstall {
            silentQueue.removeAll()
            externalSilentTargets.removeAll()
            for id in pendingAutoInstalls where waitsForSilentInstall(id) { markWaiting(id, false) }
            waitingInstalls = []
            _ = cancelAutoInstall(nil)
        }
        wifiOnly = settings.wifiOnlyDownloads
        if wifiOnly { startPathMonitor() }
        applyNetworkRule()
        updateBackgroundTask()
        schedule()
        DownloadActivity.shared.attach(self, enabled: settings.downloadLiveActivity)
        updateInstallKeepAlive()
    }

    private func startPathMonitor() {
        guard pathMonitor == nil else { return }
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { [weak self] path in
            let cellular = path.status == .satisfied && path.usesInterfaceType(.cellular)
                && !path.usesInterfaceType(.wifi) && !path.usesInterfaceType(.wiredEthernet)
            Task { @MainActor in
                guard let self else { return }
                if !cellular { self.cellularAllowed = false }
                guard cellular != self.onCellular else { return }
                self.onCellular = cellular
                self.applyNetworkRule()
                self.schedule()
            }
        }
        monitor.start(queue: DispatchQueue(label: "iPadn.network-path", qos: .utility))
        pathMonitor = monitor
    }

    /// On cellular with Wi-Fi only on, running downloads go back to the queue
    /// (keeping their progress) and continue once Wi-Fi is back.
    private func applyNetworkRule() {
        let blocked = wifiOnly && onCellular && !cellularAllowed
        if waitingForWiFi != blocked { waitingForWiFi = blocked }
        guard blocked else { return }
        for job in jobs where job.status == .running { pause(job.id, requeue: true) }
    }

    /// Downloads over cellular this time, until Wi-Fi is back.
    func downloadOverCellular() {
        cellularAllowed = true
        applyNetworkRule()
        schedule()
    }

    private func restore() async {
        let all = await session.allTasks
        for task in all {
            guard let value = task.taskDescription, let id = UUID(uuidString: value),
                  jobs.contains(where: { $0.id == id }), let download = task as? URLSessionDownloadTask else {
                task.cancel(); continue
            }
            tasks[id] = download
            if let index = jobs.firstIndex(where: { $0.id == id }) {
                if jobs[index].status == .paused || jobs[index].status == .pausing {
                    tasks.removeValue(forKey: id)
                    jobs[index].status = .pausing
                    let data: Data? = await withCheckedContinuation { continuation in
                        download.cancel(byProducingResumeData: { continuation.resume(returning: $0) })
                    }
                    if let index = jobs.firstIndex(where: { $0.id == id }), jobs[index].status == .pausing {
                        if let data { try? data.write(to: LocalResources.resumeURL(id), options: .atomic) }
                        jobs[index].status = .paused
                    }
                } else if jobs[index].status == .completed || jobs[index].status == .failed {
                    tasks.removeValue(forKey: id); download.cancel()
                } else {
                    jobs[index].status = .running
                    if download.state == .suspended { download.resume() }
                }
            }
        }
        for index in jobs.indices {
            jobs[index].reconcileDispatchVersionFromMetadata()
            let id = jobs[index].id
            if jobs[index].status == .running && tasks[id] == nil { jobs[index].status = .paused }
            if jobs[index].status == .pausing { jobs[index].status = .paused }
            if jobs[index].status == .completed, fileURL(jobs[index]) == nil {
                progressPublishedAt.removeValue(forKey: id)
                jobs[index].status = .failed; jobs[index].error = AppText.text("本地安装包已被移走或删除")
            }
        }
        restoring = false
        for job in jobs where job.status == .processing || job.status == .paused {
            if adoptFinishedPackage(job.id) { continue }
            guard job.status == .processing else { continue }
            if FileManager.default.fileExists(atPath: LocalResources.stagingURL(job.id).path) { process(job.id) }
            else { fail(job.id, error: ToolError.message(AppText.text("下载文件丢失，请重试"))) }
        }
        discoverLocalFiles()
        reconcileCompletedLocalizedNames()
        persist(); schedule()
    }

    /// Heals previously completed jobs whose `app.name` was overwritten by an ASCII Info.plist
    /// fallback (e.g. "Kwai") when `iTunesMetadata.itemName` or `*.lproj/InfoPlist.strings`
    /// carries the localized display name (e.g. "快手").
    private func reconcileCompletedLocalizedNames() {
        var needsZipCheck: [(UUID, URL)] = []
        var changed = false
        for index in jobs.indices where jobs[index].status == .completed && jobs[index].rawFormat == nil {
            let current = jobs[index].app.name.trimmingCharacters(in: .whitespacesAndNewlines)
            if let plist = jobs[index].asset?.decodedMetadata {
                let itemName = plistString(plist["itemName"]).trimmingCharacters(in: .whitespacesAndNewlines)
                if !itemName.isEmpty && itemName != current && (current.isEmpty || current.allSatisfy(\.isASCII)) {
                    jobs[index].app.name = itemName
                    changed = true
                    continue
                }
            }
            if (current.isEmpty || current.allSatisfy(\.isASCII)), let url = fileURL(jobs[index]) {
                needsZipCheck.append((jobs[index].id, url))
            }
        }
        if changed { persist() }
        guard !needsZipCheck.isEmpty else { return }
        Task { [weak self] in
            var updates: [(UUID, String)] = []
            for (id, url) in needsZipCheck {
                if let inspected = await Task.detached(priority: .utility, operation: { try? PackageService.inspect(url) }).value {
                    let resolved = inspected.name.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !resolved.isEmpty { updates.append((id, resolved)) }
                }
            }
            guard let self, !updates.isEmpty else { return }
            var mutated = false
            for (id, name) in updates {
                if let idx = self.jobs.firstIndex(where: { $0.id == id }),
                   self.jobs[idx].app.name != name,
                   name.contains(where: { !$0.isASCII }) {
                    self.jobs[idx].app.name = name
                    mutated = true
                }
            }
            if mutated { self.persist() }
        }
    }

    static func isSameDownloadVersion(_ lhs: StoreApp, _ rhs: StoreApp) -> Bool {
        guard lhs.id == rhs.id else { return false }
        let lhsExt = (lhs.externalVersionID ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let rhsExt = (rhs.externalVersionID ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !lhsExt.isEmpty && !rhsExt.isEmpty {
            return lhsExt == rhsExt
        }
        return lhs.version == rhs.version
    }

    func enqueue(_ asset: DownloadAsset) throws {
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard jobs.filter({ $0.status != .completed && $0.status != .failed }).count < maxQueued else {
            throw DownloadQueueLimitError()
        }
        guard !jobs.contains(where: { Self.isSameDownloadVersion($0.app, asset.app) &&
            $0.account == asset.account && ![.failed, .completed].contains($0.status) }) else {
            throw ToolError.message(AppText.text("这个版本已有下载任务"))
        }
        var next = jobs
        next.insert(DownloadJob(app: asset.app, asset: asset, sourceURL: asset.url, expected: asset.app.size), at: 0)
        try saveNewJobs(next)
        requestNotifications(); schedule()
    }

    func enqueueMacInstaller(_ url: URL, for app: StoreApp) throws {
        guard MacInstallerService.directPackage(url) else {
            throw ToolError.message(AppText.text("仅支持 DMG、PKG 或 ZIP 安装包链接"))
        }
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard jobs.filter({ $0.status != .completed && $0.status != .failed }).count < maxQueued else {
            throw DownloadQueueLimitError(mentionsSettings: false)
        }
        guard !jobs.contains(where: { $0.sourceURL == url && ![.completed, .failed].contains($0.status) }) else {
            throw ToolError.message(AppText.text("此安装包已有下载任务"))
        }
        var next = jobs
        next.insert(DownloadJob(app: app, sourceURL: url, packageIconScanned: true,
                                rawFormat: url.pathExtension.lowercased()), at: 0)
        try saveNewJobs(next)
        requestNotifications(); schedule()
    }

    // The authorized Mac App Store URL is provided by Apple's account-bound
    // dispatch. Protected packages are processed by StoreAgent on device after
    // the download; every finished file is verified as a XAR PKG before the
    // task completes, and Mac tasks only offer export (never iOS install).
    func enqueueOfficialMacPackage(_ offer: MacPackageOffer, for app: StoreApp) throws {
        if offer.protectedByApple {
            guard MacPackageDecryptor.isAvailable else {
                throw ToolError.message(AppText.text("当前版本不支持下载此 Mac 安装包"))
            }
            guard offer.dpInfo != nil, offer.hardwareID.count == 12 else {
                throw ToolError.message(AppText.text("暂时无法下载 Mac 安装包，请重试"))
            }
        }
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard jobs.filter({ $0.status != .completed && $0.status != .failed }).count < maxQueued else {
            throw DownloadQueueLimitError(mentionsSettings: false)
        }
        guard !jobs.contains(where: { $0.sourceURL == offer.downloadURL &&
                                      ![.completed, .failed].contains($0.status) }) else {
            throw ToolError.message(AppText.text("此安装包已有下载任务"))
        }
        var macApp = app
        // The offer's version is the Mac build's; the listing may describe the iPhone app.
        if !offer.displayVersion.isEmpty, offer.displayVersion != app.version { macApp.version = offer.displayVersion; macApp.size = 0 }
        let job = DownloadJob(app: macApp, sourceURL: offer.downloadURL, packageIconScanned: true,
                              rawFormat: "pkg", protectedMacPackage: offer.protectedByApple ? true : nil)
        if offer.protectedByApple, let dpInfo = offer.dpInfo {
            try MacPackageSecrets.save(.init(hardwareID: offer.hardwareID, dpInfo: dpInfo), for: job.id)
        }
        var next = jobs
        next.insert(job, at: 0)
        do { try saveNewJobs(next) }
        catch { MacPackageSecrets.delete(job.id); throw error }
        requestNotifications()
        schedule()
    }

    nonisolated static func isLoopbackHost(_ rawHost: String) -> Bool {
        let host = rawHost.trimmingCharacters(in: CharacterSet(charactersIn: "[] \t\r\n")).lowercased()
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
        if host.isEmpty || host == "localhost" || host.hasSuffix(".localhost") || host == "ipadn.local" {
            return true
        }
        // Reject known loopback wildcard DNS aliases (including iPadn's own local-cert domains).
        for suffix in ["localtest.me", "lvh.me", "sslip.io", "nip.io"] {
            if host == suffix || host.hasSuffix("." + suffix) { return true }
        }
        // Parse IPv4 / IPv6 numerically via inet_pton so alternate encodings ([::ffff:7f00:1], [0:0::1], etc.) cannot bypass.
        var v4 = in_addr()
        if inet_pton(AF_INET, host, &v4) == 1 {
            let ip = UInt32(bigEndian: v4.s_addr)
            let a = (ip >> 24) & 0xFF
            let b = (ip >> 16) & 0xFF
            if a == 0 || a == 127 || a == 10 { return true }
            if a == 169 && b == 254 { return true }
            if a == 172 && (16...31).contains(b) { return true }
            if a == 192 && b == 168 { return true }
            if a == 100 && (64...127).contains(b) { return true } // CGNAT / Tailscale
            return false
        }
        var v6 = in6_addr()
        if inet_pton(AF_INET6, host, &v6) == 1 {
            let bytes = withUnsafeBytes(of: &v6) { Array($0) }
            if bytes.count == 16 {
                let isUnspecified = bytes.allSatisfy { $0 == 0 }
                let isLoopback = bytes.prefix(15).allSatisfy { $0 == 0 } && bytes[15] == 1
                let isLinkLocal = bytes[0] == 0xFE && (bytes[1] & 0xC0) == 0x80
                let isUniqueLocal = (bytes[0] & 0xFE) == 0xFC
                if isUnspecified || isLoopback || isLinkLocal || isUniqueLocal { return true }
                // IPv4-mapped IPv6 (::ffff:a.b.c.d)
                let isMappedV4 = bytes.prefix(10).allSatisfy { $0 == 0 } && bytes[10] == 0xFF && bytes[11] == 0xFF
                if isMappedV4 {
                    let mapped = "\(bytes[12]).\(bytes[13]).\(bytes[14]).\(bytes[15])"
                    return isLoopbackHost(mapped)
                }
            }
        }
        // Reject bare decimal/hex/octal IPv4 shorthand (e.g. 2130706433 or 0x7f000001).
        if host.allSatisfy({ $0.isASCII && $0.isNumber }) || host.hasPrefix("0x") {
            return true
        }
        return false
    }

    func enqueueURL(_ url: URL) throws {
        guard url.scheme == "https",
              let host = url.host, !host.isEmpty, !Self.isLoopbackHost(host),
              url.user == nil, url.password == nil else {
            throw ToolError.message(AppText.text("请输入有效的下载链接"))
        }
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard jobs.filter({ $0.status != .completed && $0.status != .failed }).count < maxQueued else {
            throw DownloadQueueLimitError()
        }
        let name = url.deletingPathExtension().lastPathComponent
        var next = jobs
        next.insert(DownloadJob(app: StoreApp(id: UUID().uuidString, name: name.isEmpty ? AppText.text("导入安装包") : name), sourceURL: url), at: 0)
        try saveNewJobs(next)
        requestNotifications(); schedule()
    }

    func refreshFailedMacPackage(_ id: UUID, offer: MacPackageOffer) throws {
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard let index = jobs.firstIndex(where: { $0.id == id }),
              jobs[index].status == .failed,
              jobs[index].rawFormat == "pkg" else {
            throw ToolError.message(AppText.text("此任务无法重试"))
        }
        if offer.protectedByApple {
            guard MacPackageDecryptor.isAvailable else {
                throw ToolError.message(AppText.text("当前版本不支持下载此 Mac 安装包"))
            }
            guard let dpInfo = offer.dpInfo, offer.hardwareID.count == 12 else {
                throw ToolError.message(AppText.text("暂时无法下载 Mac 安装包，请重试"))
            }
            try MacPackageSecrets.save(.init(hardwareID: offer.hardwareID, dpInfo: dpInfo), for: id)
        } else {
            MacPackageSecrets.delete(id)
        }
        var next = jobs
        if next[index].foregroundFallback == true || next[index].error?.contains("无法创建") == true {
            fallbackForegroundIDs.insert(id)
        }
        if !offer.displayVersion.isEmpty {
            next[index].app.version = offer.displayVersion
        }
        next[index].sourceURL = offer.downloadURL
        next[index].protectedMacPackage = offer.protectedByApple ? true : nil
        next[index].error = nil
        let staged = FileManager.default.fileExists(atPath: LocalResources.stagingURL(id).path)
        next[index].status = staged ? .processing : .queued
        if !staged { next[index].downloaded = 0 }
        try saveNewJobs(next)
        try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
        if staged { process(id) } else { schedule() }
    }

    func refreshFailed(_ id: UUID, asset: DownloadAsset) throws {
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard let index = jobs.firstIndex(where: { $0.id == id }), jobs[index].status == .failed,
              jobs[index].account == asset.account, jobs[index].app.id == asset.app.id else {
            throw ToolError.message(AppText.text("账号已切换，请重新下载"))
        }
        let existingExt = (jobs[index].app.externalVersionID ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let incomingExt = (asset.app.externalVersionID ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !existingExt.isEmpty && !incomingExt.isEmpty && existingExt != incomingExt {
            throw ToolError.message(AppText.text("所选版本暂时无法下载，请换个版本重试"))
        }
        var next = jobs
        if next[index].foregroundFallback == true || next[index].error?.contains("无法创建") == true {
            fallbackForegroundIDs.insert(id)
        }
        var refreshedAsset = asset
        if refreshedAsset.app.storeMarketingVersion == nil {
            refreshedAsset.app.storeMarketingVersion = next[index].resolvedMarketingVersion
        }
        next[index].asset = refreshedAsset; next[index].sourceURL = refreshedAsset.url; next[index].app = refreshedAsset.app
        next[index].error = nil
        let staged = FileManager.default.fileExists(atPath: LocalResources.stagingURL(id).path)
        next[index].status = staged ? .processing : .queued
        if !staged { next[index].downloaded = 0; next[index].expected = refreshedAsset.app.size }
        try saveNewJobs(next)
        try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
        if staged { process(id) } else { schedule() }
    }

    private func schedule() {
        guard !restoring, storageError == nil, removingIDs.isEmpty, !waitingForWiFi else { return }
        let running = jobs.filter { $0.status == .running || $0.status == .pausing }.count
        let count = max(0, maxConcurrent - running)
        for job in jobs.filter({ $0.status == .queued }).prefix(count) { start(job.id) }
    }
    private func start(_ id: UUID) {
        guard tasks[id] == nil, let index = jobs.firstIndex(where: { $0.id == id }), let url = jobs[index].sourceURL else { return }
        LocalResources.ensureDirectoriesExist()
        let active = activeSession(for: id)
        let usingBackground = (active === session)
        let task: URLSessionDownloadTask
        let rawResume = try? Data(contentsOf: LocalResources.resumeURL(id))
        let resumeCompatible: Bool = {
            guard let rawResume, !rawResume.isEmpty else { return false }
            // Background URLSession resume blobs contain NSURLSessionResumeInfoTempFileName /
            // background identifier keys that fail when fed into an ephemeral/foreground session.
            if !usingBackground,
               let plist = try? PropertyListSerialization.propertyList(from: rawResume, format: nil) as? [String: Any],
               let bgID = plist["NSURLSessionResumeInfoBackgroundIdentifier"] as? String, !bgID.isEmpty {
                return false
            }
            return true
        }()
        if resumeCompatible, let resume = rawResume {
            task = active.downloadTask(withResumeData: resume)
        } else {
            if rawResume != nil && !resumeCompatible {
                try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
            }
            var request = URLRequest(url: url)
            request.setValue(HTTPClient.userAgent, forHTTPHeaderField: "User-Agent")
            // Also holds while iPadn is suspended and cannot watch the network.
            request.allowsCellularAccess = !wifiOnly || cellularAllowed
            task = active.downloadTask(with: request)
        }
        task.taskDescription = id.uuidString
        tasks[id] = task
        rowProgress.removeValue(forKey: id)
        transferMetrics.removeValue(forKey: id)
        progressPublishedAt.removeValue(forKey: id)
        jobs[index].status = .running; jobs[index].error = nil
        updateBackgroundTask()
        persist(); task.resume()
    }
    /// Pauses a download; `requeue` puts it back in the queue instead.
    func pause(_ id: UUID, requeue: Bool = false) {
        guard let index = jobs.firstIndex(where: { $0.id == id }) else { return }
        transferMetrics.removeValue(forKey: id)
        if jobs[index].status == .queued { jobs[index].status = .paused; persist(); return }
        guard jobs[index].status == .running, let task = tasks[id] else { return }
        jobs[index].status = .pausing; persist()
        task.cancel(byProducingResumeData: { data in
            Task { @MainActor in
                guard let index = self.jobs.firstIndex(where: { $0.id == id }), self.jobs[index].status == .pausing,
                      self.tasks[id] === task else { return }
                if let data = data { try? data.write(to: LocalResources.resumeURL(id), options: .atomic) }
                self.tasks.removeValue(forKey: id)
                self.transferMetrics.removeValue(forKey: id)
                self.updateBackgroundTask()
                // The byte count lives in the row's progress while running;
                // keep it on the task so everything showing it stays right.
                if let progress = self.rowProgress[id] { self.jobs[index] = progress.applying(to: self.jobs[index]) }
                self.jobs[index].status = requeue ? .queued : .paused
                self.persist(); self.schedule()
            }
        })
    }
    func resume(_ id: UUID) {
        guard let index = jobs.firstIndex(where: { $0.id == id }), [.paused, .failed].contains(jobs[index].status) else { return }
        if FileManager.default.fileExists(atPath: LocalResources.stagingURL(id).path) {
            jobs[index].status = .processing; jobs[index].error = nil; process(id)
        } else {
            jobs[index].status = .queued; jobs[index].error = nil; schedule()
        }
        persist()
    }
    func pauseAll() { for job in jobs where job.status == .running || job.status == .queued { pause(job.id) } }
    func resumeAll() { for job in jobs where job.status == .paused { resume(job.id) } }
    func move(from offsets: IndexSet, to destination: Int) {
        // SwiftUI's move helper lives in SwiftUI; explicit order mutation keeps service UI-independent.
        let selected = offsets.sorted().map { jobs[$0] }
        for index in offsets.sorted(by: >) { jobs.remove(at: index) }
        let adjusted = destination - offsets.filter { $0 < destination }.count
        jobs.insert(contentsOf: selected, at: max(0, min(adjusted, jobs.count)))
        persist()
    }
    /// Stops processing a Mac package (queued or running). The download is
    /// kept and the task becomes paused, so it can be continued later.
    func cancelProcessing(_ id: UUID) {
        guard let job = jobs.first(where: { $0.id == id }), job.status == .processing,
              job.protectedMacPackage == true else { return }
        guard cancelling.insert(id).inserted else { return } // repeated taps do nothing
        MacPackageDecryptor.cancel(job: id)
    }

    func remove(_ id: UUID) throws {
        guard storageError == nil else { throw ToolError.message(storageError!) }
        guard let job = jobs.first(where: { $0.id == id }) else { return }
        if job.status == .processing, job.protectedMacPackage == true {
            // Deleted once processing has stopped (see process()).
            removalAfterCancel.insert(id); cancelProcessing(id); return
        }
        guard job.status != .processing, job.status != .pausing else { throw ToolError.message(AppText.text("请等待当前文件处理或暂停完成后再删除")) }
        switch prepareAutoInstallForRemoval(ids: [id]) {
        case .irreversible:
            throw ToolError.message(AppText.text("正在执行系统安装，完成前无法删除该任务。"))
        case .cancelling:
            throw ToolError.message(AppText.text("正在取消自动安装，请稍后重试删除。"))
        case .clear:
            break
        }
        let file = fileURL(job)
        let removal = LocalResources.support.appendingPathComponent("\(id.uuidString).removing.ipa")
        if let file { try FileManager.default.moveItem(at: file, to: removal) }
        do { try saveNewJobs(jobs.filter { $0.id != id }) }
        catch {
            if let file { try FileManager.default.moveItem(at: removal, to: file) }
            throw error
        }
        tasks.removeValue(forKey: id)?.cancel()
        rowProgress.removeValue(forKey: id)
        fallbackForegroundIDs.remove(id)
        updateBackgroundTask()
        progressPublishedAt.removeValue(forKey: id)
        transferMetrics.removeValue(forKey: id)
        if file != nil { try? FileManager.default.removeItem(at: removal) }
        try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
        try? FileManager.default.removeItem(at: LocalResources.stagingURL(id))
        try? FileManager.default.removeItem(at: PackageIconService.cacheURL(id))
        packageIconCache.removeValue(forKey: id)
        try? FileManager.default.removeItem(at: Self.decryptedURL(id))
        MacPackageSecrets.delete(id)
        catalogArtworkAttempted.remove(id)
        schedule()
    }

    /// A swipe removes the durable task immediately but retains its files in
    /// the existing crash-recoverable quarantine until Undo expires.
    private struct UndoRemoval {
        let created: Date
        var expires: Date
        let jobs: [(index: Int, job: DownloadJob)]
        let resume: Set<UUID>
        let files: [(aside: URL, original: URL)]
    }
    private var undoRemovals: [UUID: UndoRemoval] = [:]
    private var undoRemovalTimers: [UUID: Task<Void, Never>] = [:]
    @Published private(set) var recentlyRestoredIDs: Set<UUID> = []
    private var restoredClearTask: Task<Void, Never>?

    private func markRecentlyRestored(_ ids: Set<UUID>) {
        guard !ids.isEmpty else { return }
        recentlyRestoredIDs.formUnion(ids)
        restoredClearTask?.cancel()
        restoredClearTask = Task { @MainActor [weak self] in
            do { try await compatSleep(milliseconds: Double(900)) } catch { return }
            self?.recentlyRestoredIDs.removeAll()
        }
    }

    func removeReversibly(_ id: UUID) async throws -> (token: UUID, created: Date)? {
        let token = UUID()
        guard try await removeBatch([id], undoToken: token) > 0,
              let receipt = undoRemovals[token] else { return nil }
        return (token, receipt.created)
    }

    func removeBatchReversibly(_ ids: Set<UUID>) async throws -> (token: UUID, count: Int, created: Date)? {
        guard !ids.isEmpty else { return nil }
        let token = UUID()
        let count = try await removeBatch(ids, undoToken: token)
        guard count > 0, let receipt = undoRemovals[token] else { return nil }
        return (token, count, receipt.created)
    }

    /// Consecutive swipes share the latest notice and five-second window.
    func extendRemovalUndo(_ tokens: [UUID], until deadline: Date) {
        for token in tokens where undoRemovals[token] != nil {
            undoRemovals[token]?.expires = deadline
            armRemovalUndo(token)
        }
    }

    private func armRemovalUndo(_ token: UUID) {
        undoRemovalTimers.removeValue(forKey: token)?.cancel()
        guard let receipt = undoRemovals[token] else { return }
        let delay = max(0, receipt.expires.timeIntervalSinceNow)
        undoRemovalTimers[token] = Task { @MainActor [weak self] in
            do { try await compatSleep(seconds: Double(delay)) } catch { return }
            self?.finishRemovalUndo(token)
        }
    }

    private func finishRemovalUndo(_ token: UUID) {
        guard let receipt = undoRemovals.removeValue(forKey: token) else { return }
        undoRemovalTimers.removeValue(forKey: token)?.cancel()
        for item in receipt.jobs { packageIconCache.removeValue(forKey: item.job.id) }
        persistQueue.async {
            for file in receipt.files { try? FileManager.default.removeItem(at: file.aside) }
            for item in receipt.jobs {
                let id = item.job.id
                for url in [LocalResources.resumeURL(id), LocalResources.stagingURL(id), PackageIconService.cacheURL(id), Self.decryptedURL(id)] {
                    try? FileManager.default.removeItem(at: url)
                }
                TemporaryExportSweeper.removeShareHardLink(for: id)
                MacPackageSecrets.delete(id)
            }
        }
    }

    func undoRemoval(_ token: UUID) async throws {
        try await undoRemovalGroup([token])
    }

    /// Claim the whole group before the first disk await. Otherwise the expiry
    /// timer for a later receipt can delete its files while an earlier save runs.
    func undoRemovalGroup(_ tokens: [UUID]) async throws {
        guard removingIDs.isEmpty, !loadingJobs else { throw ToolError.message(AppText.text("正在保存任务，请稍后重试")) }
        guard storageError == nil else { throw ToolError.message(storageError!) }
        let now = Date()
        var claimed: [(token: UUID, receipt: UndoRemoval)] = []
        var seen = Set<UUID>()
        let unique = tokens.filter { seen.insert($0).inserted }
        for token in unique.reversed() {
            guard let receipt = undoRemovals[token] else { continue }
            guard now < receipt.expires else { finishRemovalUndo(token); continue }
            guard !receipt.jobs.contains(where: { item in jobs.contains { $0.id == item.job.id } }) else { continue }
            claimed.append((token, receipt))
        }
        guard !claimed.isEmpty else { return }
        for item in claimed {
            undoRemovals.removeValue(forKey: item.token)
            undoRemovalTimers.removeValue(forKey: item.token)?.cancel()
        }
        let entries = claimed.flatMap { $0.receipt.jobs }
        removingIDs = Set(entries.map { $0.job.id })
        defer { removingIDs.removeAll(); persist(); schedule(); finishBackgroundIfReady() }
        let insert: ([DownloadJob]) -> [DownloadJob] = { current in
            var result = current
            // Each receipt's indices describe the list at that deletion; undo
            // deletions in reverse order rather than sorting across receipts.
            for item in claimed {
                for entry in item.receipt.jobs.sorted(by: { $0.index < $1.index }) {
                    result.insert(entry.job, at: min(entry.index, result.count))
                }
            }
            return result
        }
        let restored = insert(currentJobs), save = saveJobs
        let moves = claimed.flatMap { $0.receipt.files }.map { ($0.aside, $0.original) }
        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                persistQueue.async {
                    do {
                        try DownloadRemovalTransaction.perform(moves) { try save(restored) }
                        continuation.resume()
                    } catch { continuation.resume(throwing: error) }
                }
            }
            // Publish once, preserving unrelated updates delivered during I/O.
            for entry in entries { packageIconCache.removeValue(forKey: entry.job.id) }
            let restoredIDs = Set(entries.map(\.job.id))
            jobs = insert(currentJobs)
            markRecentlyRestored(restoredIDs)
            for id in claimed.reduce(into: Set<UUID>(), { $0.formUnion($1.receipt.resume) }) { resume(id) }
        } catch {
            for item in claimed {
                undoRemovals[item.token] = item.receipt
                armRemovalUndo(item.token)
            }
            throw error
        }
    }

    /// One durable commit for a batch. Pause live transfers first; move packages
    /// aside and roll them back if the task-list write fails. Disk work is serial
    /// with earlier progress saves, and never runs on the main actor.
    func removeBatch(_ ids: Set<UUID>) async throws -> Int {
        try await removeBatch(ids, undoToken: nil)
    }

    private func removeBatch(_ ids: Set<UUID>, undoToken: UUID?) async throws -> Int {
        if undoToken != nil && (!removingIDs.isEmpty || loadingJobs) {
            let queueDeadline = Date().addingTimeInterval(2)
            while (!removingIDs.isEmpty || loadingJobs) && Date() < queueDeadline {
                try await compatSleep(milliseconds: Double(20))
            }
            try Task.checkCancellation()
        }
        guard removingIDs.isEmpty, !loadingJobs else { throw ToolError.message(AppText.text("正在保存任务，请稍后重试")) }
        guard storageError == nil else { throw ToolError.message(storageError!) }
        let selected = jobs.filter { ids.contains($0.id) }
        guard !selected.contains(where: { $0.status == .processing || $0.status == .pausing }) else {
            throw ToolError.message(AppText.text("请等待当前文件处理或暂停完成后再删除"))
        }
        switch prepareAutoInstallForRemoval(ids: ids) {
        case .irreversible:
            throw ToolError.message(AppText.text("正在执行系统安装，完成前无法删除该任务。"))
        case .cancelling:
            let cancelDeadline = Date().addingTimeInterval(3)
            while let activeID = autoInstalling?.id, ids.contains(activeID), Date() < cancelDeadline {
                if autoInstalling?.canCancel == false {
                    throw ToolError.message(AppText.text("正在执行系统安装，完成前无法删除该任务。"))
                }
                try await compatSleep(milliseconds: Double(50))
            }
            if let activeID = autoInstalling?.id, ids.contains(activeID) {
                throw ToolError.message(AppText.text("自动安装尚在停止，请稍后重试删除。"))
            }
        case .clear:
            break
        }
        for job in selected where job.status == .running { pause(job.id) }
        let deadline = Date().addingTimeInterval(15)
        while jobs.contains(where: { ids.contains($0.id) && $0.status == .pausing }) {
            guard Date() < deadline else { throw ToolError.message(AppText.text("暂停下载尚未完成，请稍后重试删除")) }
            try await compatSleep(milliseconds: Double(50))
        }
        try Task.checkCancellation()
        guard removingIDs.isEmpty else { throw ToolError.message(AppText.text("正在删除任务，请稍后重试")) }
        let targets = jobs.filter { ids.contains($0.id) }
        guard !targets.contains(where: { $0.status == .processing }) else { throw ToolError.message(AppText.text("任务正在处理，请稍后重试")) }
        let removed = Set(targets.map(\.id))
        guard !removed.isEmpty else { return 0 }
        removingIDs = removed
        defer { removingIDs.removeAll(); persist(); schedule(); finishBackgroundIfReady() }
        let next = currentJobs.filter { !removed.contains($0.id) }, save = saveJobs
        let files = targets.compactMap { job in fileURL(job).map { (job.id, $0) } }
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            persistQueue.async {
                let moves = files.map { id, file in
                    (from: file, to: LocalResources.support.appendingPathComponent("\(id.uuidString).removing.ipa"))
                }
                do {
                    try DownloadRemovalTransaction.perform(moves) { try save(next) }
                } catch { continuation.resume(throwing: error); return }
                if undoToken == nil {
                    for move in moves { try? FileManager.default.removeItem(at: move.to) }
                    for id in removed {
                        for url in [LocalResources.resumeURL(id), LocalResources.stagingURL(id), PackageIconService.cacheURL(id), Self.decryptedURL(id)] {
                            try? FileManager.default.removeItem(at: url)
                        }
                        TemporaryExportSweeper.removeShareHardLink(for: id)
                        MacPackageSecrets.delete(id)
                    }
                }
                continuation.resume()
            }
        }
        if let undoToken {
            let created = Date()
            undoRemovals[undoToken] = UndoRemoval(created: created,
                expires: created.addingTimeInterval(UndoNotice.duration),
                jobs: currentJobs.enumerated().compactMap { index, job in
                    removed.contains(job.id) ? (index, job) : nil
                },
                resume: Set(selected.filter { $0.status == .running }.map(\.id)),
                files: files.map { id, original in
                    (LocalResources.support.appendingPathComponent("\(id.uuidString).removing.ipa"), original)
                })
            armRemovalUndo(undoToken)
        }
        recentlyRestoredIDs.subtract(removed)
        jobs.removeAll { removed.contains($0.id) }
        for id in removed {
            tasks.removeValue(forKey: id)?.cancel()
            rowProgress.removeValue(forKey: id); transferMetrics.removeValue(forKey: id)
            progressPublishedAt.removeValue(forKey: id); fallbackForegroundIDs.remove(id)
            catalogArtworkAttempted.remove(id); packageIconCache.removeValue(forKey: id)
        }
        updateBackgroundTask()
        return removed.count
    }

    /// Crash between moving a package aside and committing jobs must never
    /// make a retained package disappear. A committed removal has no job left.
    nonisolated static func recoverRemovals(_ jobs: [DownloadJob], support: URL = LocalResources.support,
                                           packages: URL = LocalResources.packages) throws {
        let fm = FileManager.default
        let root = packages.resolvingSymlinksInPath().standardizedFileURL
        let retained = Dictionary(jobs.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        let files = (try? fm.contentsOfDirectory(at: support, includingPropertiesForKeys: [.isRegularFileKey])) ?? []
        for aside in files where aside.lastPathComponent.hasSuffix(".removing.ipa") {
            let prefix = String(aside.lastPathComponent.dropLast(".removing.ipa".count))
            guard let id = UUID(uuidString: prefix),
                  (try? aside.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else { continue }
            if let job = retained[id] {
                guard let name = job.localFilename, !name.contains("/"), !name.contains("\\"), name != ".", name != ".." else { continue }
                let destination = root.appendingPathComponent(name).standardizedFileURL
                guard destination.deletingLastPathComponent() == root else { continue }
                if !fm.fileExists(atPath: destination.path) { try fm.moveItem(at: aside, to: destination) }
            } else {
                try? fm.removeItem(at: aside)
                for sidecar in [LocalResources.resumeURL(id), LocalResources.stagingURL(id),
                                PackageIconService.cacheURL(id), Self.decryptedURL(id)] {
                    try? fm.removeItem(at: sidecar)
                }
                TemporaryExportSweeper.removeShareHardLink(for: id)
                MacPackageSecrets.delete(id)
            }
        }
        // Sweep orphaned crash-interrupted `.received` and `.working.ipa` temp files.
        for file in files where file.lastPathComponent.hasSuffix(".received") || file.lastPathComponent.hasSuffix(".working.ipa") {
            try? fm.removeItem(at: file)
        }
    }

    nonisolated static func decryptedURL(_ id: UUID) -> URL {
        LocalResources.support.appendingPathComponent("\(id.uuidString).decrypted.pkg")
    }
    func metrics(for id: UUID) -> TransferMetrics? { transferMetrics[id] }

    func fileURL(_ job: DownloadJob) -> URL? {
        job.localFilename.flatMap(LocalResources.packageURL)
    }

    /// The file to hand to the share sheet: named after the app and version
    /// ("OneDrive 26.1.4.ipa") rather than the internal UUID. A hard link, so
    /// it costs no space; the stored file itself is never renamed.
    func exportURL(_ job: DownloadJob) -> URL? {
        guard let file = fileURL(job) else { return nil }
        let illegal = CharacterSet(charactersIn: "/\\:?%*|\"<>").union(.newlines).union(.controlCharacters)
        let clean = { (s: String) in s.components(separatedBy: illegal).joined(separator: " ").trimmingCharacters(in: .whitespaces) }
        let name = clean(job.app.name), version = clean(job.storeVersion)
        let base = [name, version].filter { !$0.isEmpty }.joined(separator: " ")
        guard !base.isEmpty else { return file }
        let ext = file.pathExtension
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("Share", isDirectory: true)
            .appendingPathComponent(job.id.uuidString, isDirectory: true)
        let target = folder.appendingPathComponent(String(base.prefix(120))).appendingPathExtension(ext)
        do {
            try? FileManager.default.removeItem(at: folder)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            do { try FileManager.default.linkItem(at: file, to: target) }
            catch { try FileManager.default.copyItem(at: file, to: target) }
            return target
        } catch {
            return file
        }
    }

    func packageIconURL(_ job: DownloadJob) -> URL? {
        let url = PackageIconService.cacheURL(job.id)
        if let exists = packageIconCache[job.id] { return exists ? url : nil }
        let exists = FileManager.default.fileExists(atPath: url.path)
        packageIconCache[job.id] = exists
        return exists ? url : nil
    }

    /// Packages whose icon scan has started but not finished.
    private static let iconScanKey = "packageIconScansInProgress"
    func loadPackageIcons() async {
        guard !iconsLoading else { return }
        iconsLoading = true
        var pendingPersistCount = 0
        defer {
            if pendingPersistCount > 0 { persist() }
            iconsLoading = false
        }
        // A scan that ended the app last time is not tried again: the list
        // would otherwise end the app on every launch.
        var interrupted = Set(UserDefaults.standard.stringArray(forKey: Self.iconScanKey) ?? [])
        for job in jobs where job.status == .completed && job.rawFormat == nil {
            guard let file = fileURL(job), !Task.isCancelled else { continue }
            if job.packageIconScanned != true, interrupted.remove(job.id.uuidString) != nil,
               let index = jobs.firstIndex(where: { $0.id == job.id }) {
                jobs[index].packageIconScanned = true
                if jobs[index].app.iconURL == nil { jobs[index].app.iconURL = jobs[index].asset?.app.iconURL }
                pendingPersistCount += 1
                if pendingPersistCount >= 8 { persist(); pendingPersistCount = 0 }
                UserDefaults.standard.set(Array(interrupted), forKey: Self.iconScanKey)
                continue
            }
            // Older versions scanned before they could keep a small icon get one more look.
            let rescan = job.packageIconScanned == true && job.isOlderVersion && packageIconURL(job) == nil
                && olderIconRetried.insert(job.id).inserted
            if job.packageIconScanned != true || rescan {
                interrupted.insert(job.id.uuidString)
                UserDefaults.standard.set(Array(interrupted), forKey: Self.iconScanKey)
                // With store artwork available, only keep a package icon that is
                // sharp at list size (64 pt at 3x). An older version keeps its own
                // icon at any size: the store shows today's, which may look different.
                let minimum = job.displayApp(packageIcon: nil).iconURL == nil || job.isOlderVersion ? 0 : 180
                _ = await Task.detached(priority: .utility) {
                    try? PackageIconService.save(from: file, id: job.id, minimumPixels: minimum)
                }.value
                guard let index = jobs.firstIndex(where: { $0.id == job.id }) else {
                    try? FileManager.default.removeItem(at: PackageIconService.cacheURL(job.id))
                    packageIconCache.removeValue(forKey: job.id)
                    continue
                }
                packageIconCache.removeValue(forKey: job.id)
                jobs[index].packageIconScanned = true
                interrupted.remove(job.id.uuidString)
                UserDefaults.standard.set(Array(interrupted), forKey: Self.iconScanKey)
                // Never erase the catalog icon because IPA icon extraction failed.
                if jobs[index].app.iconURL == nil {
                    jobs[index].app.iconURL = jobs[index].asset?.app.iconURL
                }
                pendingPersistCount += 1
                if pendingPersistCount >= 8 { persist(); pendingPersistCount = 0 }
            }
            // Icons cached before small package PNGs were rejected: fall back to
            // the sharper store artwork.
            if iconSizeChecked.insert(job.id).inserted, let cached = packageIconURL(job),
               job.displayApp(packageIcon: nil).iconURL != nil, !job.isOlderVersion,
               PackageIconService.pixelWidth(cached) < 180 {
                try? FileManager.default.removeItem(at: cached)
                packageIconCache[job.id] = false
                objectWillChange.send()
            }
            // tvOS packages keep their icon in a layered asset catalog, and the
            // stored artwork can be the shared App ID's iPhone icon. Replace
            // the cached icon once with the Apple TV catalog artwork.
            guard job.platformLabel == "tvOS", job.appleTVArtwork != true,
                  catalogArtworkAttempted.insert(job.id).inserted,
                  jobs.contains(where: { $0.id == job.id }) else { continue }
            var tvArtwork: URL?
            if job.app.id.allSatisfy({ $0.isASCII && $0.isNumber }) {
                let countries = artworkCountry == "US" ? ["US"] : [artworkCountry, "US"]
                for country in countries {
                    if Task.isCancelled { break }
                    let context = StoreContext(country: country, platform: .tvOS)
                    if let listing = try? await StoreService.platformApp(job.app.id, store: context),
                       let icon = listing.iconURL {
                        tvArtwork = icon
                        break
                    }
                }
            }
            let current = jobs.first { $0.id == job.id } ?? job
            let fallback = packageIconURL(job) == nil ? current.displayApp(packageIcon: nil).iconURL : nil
            guard let artwork = tvArtwork ?? fallback, !Task.isCancelled else { continue }
            if (try? await PackageIconService.saveCatalogArtwork(from: artwork, id: job.id)) == true {
                // A download can be deleted while the artwork request is in flight.
                guard let index = jobs.firstIndex(where: { $0.id == job.id }) else {
                    try? FileManager.default.removeItem(at: PackageIconService.cacheURL(job.id))
                    packageIconCache.removeValue(forKey: job.id)
                    continue
                }
                packageIconCache.removeValue(forKey: job.id)
                if tvArtwork != nil {
                    jobs[index].app.iconURL = artwork
                    jobs[index].appleTVArtwork = true
                    persist()
                }
                objectWillChange.send()
            }
        }
    }

    func importFile(_ source: URL) async throws {
        guard storageError == nil else { throw ToolError.message(storageError!) }
        let id = UUID()
        let inspected = try await Task.detached(priority: .userInitiated) {
            try PackageImportService.prepare(source, id: id)
        }.value
        guard storageError == nil else {
            try? FileManager.default.removeItem(at: LocalResources.stagingURL(id))
            throw ToolError.message(storageError!)
        }
        var next = jobs
        next.insert(DownloadJob(id: id, app: inspected, status: .processing), at: 0)
        do { try saveNewJobs(next) }
        catch { try? FileManager.default.removeItem(at: LocalResources.stagingURL(id)); throw error }
        process(id)
    }

    private func process(_ id: UUID) {
        guard let job = jobs.first(where: { $0.id == id }), processingIDs.insert(id).inserted else { return }
        var backgroundTask: UIBackgroundTaskIdentifier = .invalid
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Prepare IPA") { [weak self] in
            // Called on the main thread; the task must be ended before returning.
            MainActor.assumeIsolated {
                self?.persist(wait: true)
                let completion = self?.backgroundCompletion; self?.backgroundCompletion = nil; completion?()
                if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask); backgroundTask = .invalid }
            }
        }
        let monitor: Task<Void, Never>? = job.protectedMacPackage == true
            ? Task { await self.monitorMacProcessing(id) } : nil
        Task {
            defer {
                monitor?.cancel()
                self.processingDetail.removeValue(forKey: id)
                self.processingIDs.remove(id)
                if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask); backgroundTask = .invalid }
                self.finishBackgroundIfReady()
            }
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    if job.protectedMacPackage == true {
                        // StoreAgent turns Apple's protected download into the
                        // real PKG, which must then pass full XAR validation.
                        let secret = try MacPackageSecrets.load(id)
                        let decrypted = Self.decryptedURL(id)
                        defer { try? FileManager.default.removeItem(at: decrypted) }
                        try await MacPackageDecryptor.process(job: id, hardwareID: secret.hardwareID, dpInfo: secret.dpInfo,
                                                              from: LocalResources.stagingURL(id), to: decrypted)
                        return try MacPackageStorage.finish(staging: decrypted, job: job)
                    }
                    if job.rawFormat != nil {
                        return try MacPackageStorage.finish(staging: LocalResources.stagingURL(id), job: job)
                    }
                    let result = try PackageService.finish(staging: LocalResources.stagingURL(id), id: id, asset: job.asset)
                    _ = try? PackageIconService.save(from: LocalResources.packages.appendingPathComponent(result.0), id: id)
                    return result
                }.value
                guard let index = self.jobs.firstIndex(where: { $0.id == id }) else { return }
                self.transferMetrics.removeValue(forKey: id)
                self.rowProgress.removeValue(forKey: id)
                self.packageIconCache.removeValue(forKey: id)
                self.jobs[index].localFilename = result.0
                self.jobs[index].app = job.completing(with: result.1)
                self.jobs[index].packageIconScanned = true
                self.jobs[index].status = .completed
                self.jobs[index].downloaded = result.1.size; self.jobs[index].expected = result.1.size
                self.jobs[index].error = nil
                try? FileManager.default.removeItem(at: LocalResources.stagingURL(id))
                try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
                if job.protectedMacPackage == true { MacPackageSecrets.delete(id) }
                self.persist()
                // Only downloaded Apple Store iOS/iPadOS app packages auto-install; external URLs, imported files, Mac packages, and Apple TV IPAs require manual action.
                let installs = self.autoInstall && job.canInstallOnCurrentDevice && job.protectedMacPackage != true && job.asset != nil
                // Kept across launches only for the silent install, which iOS can interrupt.
                if installs && self.silentInstall { self.markWaiting(id, true) }
                if installs && self.silentInstall {
                    self.installSilently(id)
                } else {
                    self.notify(title: AppText.text("安装包已准备好"), body: result.1.name + " " + result.1.version)
                    if installs, !self.pendingAutoInstalls.contains(id) { self.pendingAutoInstalls.append(id) }
                }
                Task { await self.loadPackageIcons() }
            } catch is CancellationError {
                self.cancelling.remove(id)
                // Cancelled by the user: keep the download, continue later.
                guard let index = self.jobs.firstIndex(where: { $0.id == id }) else { return }
                self.jobs[index].status = .paused
                self.jobs[index].error = nil
                self.persist(); self.schedule()
                if self.removalAfterCancel.remove(id) != nil { try? self.remove(id) }
            } catch {
                self.cancelling.remove(id)
                // Retrying must download again rather than reprocess the same bad
                // file (imported files have nothing to download and keep theirs).
                // A protected Mac package keeps its download: its processing
                // can fail for transient reasons (component download, network).
                if job.protectedMacPackage != true, job.sourceURL != nil {
                    try? FileManager.default.removeItem(at: LocalResources.stagingURL(id))
                    try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
                    if let index = self.jobs.firstIndex(where: { $0.id == id }) { self.jobs[index].downloaded = 0 }
                }
                self.fail(id, error: error)
            }
        }
    }

    private func monitorMacProcessing(_ id: UUID) async {
        let total = (try? FileManager.default.attributesOfItem(atPath: LocalResources.stagingURL(id).path)[.size] as? NSNumber)?.int64Value ?? 0
        while !Task.isCancelled {
            if MacPackageDecryptor.currentJob != id {
                processingDetail[id] = AppText.text("排队等待处理")
            } else if let status = MacPackageDecryptor.status() {
                var text = status.stage.title
                if status.stage == .decrypting, total > 0 {
                    text += String(format: " %.0f%%", min(100, Double(status.bytes) * 100 / Double(total)))
                } else if status.stage == .components {
                    text += AppText.text("（首次需下载约 47 MB）")
                }
                processingDetail[id] = text
            }
            try? await Task.sleep(nanoseconds: 500_000_000)
        }
    }

    /// Processing moves the result into Packages before the job is saved as
    /// completed; if the app was killed in between, finish the job from that file.
    private func adoptFinishedPackage(_ id: UUID) -> Bool {
        let prefix = id.uuidString + "-"
        guard let index = jobs.firstIndex(where: { $0.id == id }),
              let names = try? FileManager.default.contentsOfDirectory(atPath: LocalResources.packages.path),
              let name = names.first(where: { $0.hasPrefix(prefix) }) else { return false }
        jobs[index].localFilename = name
        jobs[index].status = .completed
        jobs[index].error = nil
        if let size = (try? FileManager.default.attributesOfItem(atPath: LocalResources.packages.appendingPathComponent(name).path)[.size] as? NSNumber)?.int64Value {
            jobs[index].downloaded = size; jobs[index].expected = size
        }
        try? FileManager.default.removeItem(at: LocalResources.stagingURL(id))
        try? FileManager.default.removeItem(at: LocalResources.resumeURL(id))
        if jobs[index].protectedMacPackage == true { MacPackageSecrets.delete(id) }
        return true
    }

    private func discoverLocalFiles() {
        guard storageError == nil else { return }
        Task {
            let files = await Task.detached(priority: .utility) {
                ((try? FileManager.default.contentsOfDirectory(at: LocalResources.packages, includingPropertiesForKeys: nil)) ?? [])
                    .filter { $0.pathExtension.lowercased() == "ipa" && LocalResources.packageURL($0.lastPathComponent) != nil }
            }.value
            for file in files {
                guard !self.jobs.contains(where: { $0.localFilename == file.lastPathComponent }) else { continue }
                do {
                    let app = try await Task.detached(priority: .utility) { try PackageService.inspect(file) }.value
                    guard !self.jobs.contains(where: { $0.localFilename == file.lastPathComponent }) else { continue }
                    self.jobs.append(DownloadJob(app: app, status: .completed, downloaded: app.size, expected: app.size, localFilename: file.lastPathComponent))
                    self.persist()
                } catch { self.discoveryWarning = AppText.text("本地 IPA 无法读取，已保留原文件；其他任务可继续使用：\(file.lastPathComponent)\n\(error.localizedDescription)") }
            }
        }
    }

    private func fail(_ id: UUID, error: Error) {
        guard let index = jobs.firstIndex(where: { $0.id == id }) else { return }
        tasks.removeValue(forKey: id)
        rowProgress.removeValue(forKey: id)
        transferMetrics.removeValue(forKey: id)
        progressPublishedAt.removeValue(forKey: id)
        updateBackgroundTask()
        RequestFailureLog.record(nil, status: (error as? HTTPStatusError)?.code,
                                 error: error is HTTPStatusError || error is ToolError ? nil : error, stage: "download")
        jobs[index].status = .failed; jobs[index].error = error.localizedDescription
        jobs[index].foregroundFallback = Self.cannotCreateFile(error)
        persist(); schedule()
        notify(title: AppText.text("下载任务失败"), body: AppText.text("\(jobs[index].app.name)：\(error.localizedDescription)"))
    }
    /// Saves a snapshot of the task list. Encoding and writing happen on a
    /// serial background queue, so writes stay in order and the main thread
    /// never waits for the disk; `wait` blocks until it is written (used when
    /// the app is about to be suspended).
    /// A background session that cannot create its file needs a foreground
    /// retry. Checked on the error, never on its localized text.
    private static func cannotCreateFile(_ error: Error) -> Bool {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain, ns.code == NSURLErrorCannotCreateFile || ns.code == NSURLErrorCannotWriteToFile {
            return true
        }
        let text = error.localizedDescription
        return text.contains("无法创建") || text.localizedCaseInsensitiveContains("could not create")
    }
    private func persist(wait: Bool = false) {
        // storageError means the saved list could not be read; never overwrite it.
        guard storageError == nil, !loadingJobs, removingIDs.isEmpty else { return }
        let snapshot = currentJobs, save = saveJobs
        lastSave = Date()
        let write: @Sendable () -> Void = { [weak self] in
            let failed: Bool
            do { try save(snapshot); failed = false } catch { failed = true }
            Task { @MainActor [weak self] in
                guard let self else { return }
                if failed { self.saveWarning = AppText.text("下载任务暂时无法保存，请检查设备存储空间。") }
                else if self.saveWarning != nil { self.saveWarning = nil }
            }
        }
        if wait { persistQueue.sync(execute: write) } else { persistQueue.async(execute: write) }
    }
    private func saveNewJobs(_ next: [DownloadJob]) throws {
        guard !loadingJobs, removingIDs.isEmpty else { throw ToolError.message(AppText.text("正在保存任务，请稍后重试")) }
        let next = next.map { rowProgress[$0.id]?.applying(to: $0) ?? $0 }
        // Commit the file before publishing a newly enqueued/imported/retried
        // task; on the same queue, after any earlier pending save.
        try persistQueue.sync { try saveJobs(next) }
        jobs = next; lastSave = Date()
    }
    private func requestNotifications() {
        guard notifications else { return }
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }
    private enum RemovalAutoInstallState { case clear, cancelling, irreversible }

    private func prepareAutoInstallForRemoval(ids: Set<UUID>) -> RemovalAutoInstallState {
        pendingAutoInstalls.removeAll { ids.contains($0) }
        silentQueue.removeAll { ids.contains($0) }
        for id in ids { markWaiting(id, false) }
        guard let active = autoInstalling, ids.contains(active.id) else { return .clear }
        guard active.canCancel else { return .irreversible }
        _ = cancelAutoInstall(active.id)
        return autoInstalling?.id == active.id ? .cancelling : .clear
    }

    /// Cancels a queued or active automatic installation if still in a cancellable
    /// stage (`connecting`/`uploading`). Returns `.irreversible` once handed to installd.
    @discardableResult
    func cancelAutoInstall(_ id: UUID? = nil) -> AutoInstallCancelOutcome {
        var removedAny = false
        if let id {
            if pendingAutoInstalls.contains(id) { pendingAutoInstalls.removeAll { $0 == id }; removedAny = true }
            if pendingExternalAutoInstalls.contains(where: { $0.id == id }) { pendingExternalAutoInstalls.removeAll { $0.id == id }; removedAny = true }
            if silentQueue.contains(id) { silentQueue.removeAll { $0 == id }; removedAny = true }
            if externalSilentTargets.removeValue(forKey: id) != nil { removedAny = true }
            if waitsForSilentInstall(id) { markWaiting(id, false); removedAny = true }
        } else {
            if !pendingAutoInstalls.isEmpty || !pendingExternalAutoInstalls.isEmpty || !silentQueue.isEmpty || !externalSilentTargets.isEmpty || !waitingInstalls.isEmpty { removedAny = true }
            pendingAutoInstalls.removeAll()
            pendingExternalAutoInstalls.removeAll()
            silentQueue.removeAll()
            externalSilentTargets.removeAll()
            waitingInstalls = []
        }
        guard let active = autoInstalling, id == nil || active.id == id else {
            updateInstallKeepAlive()
            if removedAny { autoInstallNotice = AppText.text("已取消自动安装") }
            return removedAny ? .cancelled : .idle
        }
        guard active.canCancel else {
            autoInstallNotice = AppText.text("已进入系统安装阶段，无法取消")
            return .irreversible
        }
        silentCancelledIDs.insert(active.id)
        markWaiting(active.id, false)
        activeSilentAttemptTask?.cancel()
        if id == nil || silentQueue.isEmpty { silentInstallTask?.cancel() }
        NativeInstaller.cancel()
        updateInstallKeepAlive()
        return .cancelled
    }

    private final class AutoInstallProgressRelay: @unchecked Sendable {
        private let lock = NSLock()
        private var lastStage: AutoInstallStage?
        private var lastFraction: Double = -1
        private var lastSentAt: TimeInterval = 0

        func accept(stage: AutoInstallStage, fraction: Double) -> Bool {
            lock.lock()
            defer { lock.unlock() }
            let now = ProcessInfo.processInfo.systemUptime
            let stageChanged = lastStage != stage
            let complete = fraction >= 0.999 && lastFraction < 0.999
            let movedEnough = abs(fraction - lastFraction) >= 0.01 && now - lastSentAt >= 0.1
            guard stageChanged || complete || movedEnough else { return false }
            lastStage = stage
            lastFraction = fraction
            lastSentAt = now
            return true
        }
    }

    /// Hands a completed external IPA (e.g. TestFlight) into the same automatic-install
    /// and notification pipeline used by App Store downloads.
    func enqueueExternalAutoInstall(_ target: ExternalAutoInstallTarget) {
        let name = target.job.userFacingTitle
        let version = target.job.userFacingVersion
        guard autoInstall else {
            notify(title: AppText.text("安装包已准备好"), body: version.isEmpty ? name : (name + " " + version))
            return
        }
        if silentInstall {
            externalSilentTargets[target.id] = target
            installSilently(target.id)
        } else {
            notify(title: AppText.text("安装包已准备好"), body: version.isEmpty ? name : (name + " " + version))
            if !pendingExternalAutoInstalls.contains(where: { $0.fileURL == target.fileURL }) {
                pendingExternalAutoInstalls.append(target)
            }
        }
    }

    func notifyExternalDownloadFailed(name: String, message: String) {
        notify(title: AppText.text("下载任务失败"), body: AppText.text("\(name)：\(message)"))
    }

    func isExternalSilentInstallPending(fileURL: URL) -> Bool {
        guard silentInstall else { return false }
        let path = fileURL.standardizedFileURL.path
        return externalSilentTargets.values.contains { $0.fileURL.standardizedFileURL.path == path }
    }

    /// Installs finished downloads one at a time through native installation,
    /// without the install sheet. One that can't finish (no connection, iOS
    /// ended the background time) gets the sheet when iPadn is open again.
    private func installSilently(_ id: UUID) {
        // Returning to the foreground resumes waiting installs. The active
        // install has already left the queue, but must not be enqueued again.
        guard autoInstalling?.id != id, !silentQueue.contains(id) else { return }
        silentCancelledIDs.remove(id)
        silentQueue.append(id)
        guard !silentRunning else { return }
        silentRunning = true
        silentInstallTask = Task { @MainActor [weak self] in
            guard let self else { return }
            defer {
                self.activeSilentAttemptTask = nil
                self.silentRunning = false
                self.silentInstallTask = nil
            }
            while !self.silentQueue.isEmpty {
                let id = self.silentQueue.removeFirst()
                let externalTarget = self.externalSilentTargets[id]
                let resolved: (job: DownloadJob, file: URL)? = {
                    if let externalTarget, FileManager.default.fileExists(atPath: externalTarget.fileURL.path) {
                        return (externalTarget.job, externalTarget.fileURL)
                    }
                    if let job = self.jobs.first(where: { $0.id == id && $0.status == .completed }),
                       let file = self.fileURL(job) {
                        return (job, file)
                    }
                    return nil
                }()
                guard self.autoInstall, self.silentInstall, !self.silentCancelledIDs.contains(id),
                      let (job, file) = resolved else {
                    self.externalSilentTargets.removeValue(forKey: id)
                    self.markWaiting(id, false); continue
                }
                let name = job.userFacingTitle
                self.autoInstallNotice = AppText.text("正在自动安装 \(name)")
                self.autoInstalled = nil
                self.autoInstallFailed = nil
                self.autoInstallCancelled = nil
                self.autoInstalling = AutoInstallProgress(id: id, name: name, fraction: 0, canCancel: true, stage: .connecting)
                if externalTarget == nil {
                    self.inFlightAutoInstallID = id.uuidString
                }
                defer {
                    if self.inFlightAutoInstallID == id.uuidString { self.inFlightAutoInstallID = nil }
                    if self.autoInstalling?.id == id { self.autoInstalling = nil }
                    self.activeSilentAttemptTask = nil
                }
                do {
                    let relay = AutoInstallProgressRelay()
                    let attemptTask = Task {
                        try await NativeInstaller.install(package: file, bundleID: job.app.bundleID) { phase in
                            // Sending the package is most of the wait; the system's own step follows.
                            let stage: AutoInstallStage
                            let fraction: Double
                            switch phase {
                            case .uploading(let done):
                                stage = .uploading
                                fraction = done * 0.7
                            case .installing(let done):
                                stage = .installing
                                fraction = 0.7 + done * 0.3
                            case .connecting:
                                stage = .connecting
                                fraction = 0
                            }
                            let cancellable = phase.isCancellable
                            guard relay.accept(stage: stage, fraction: fraction) else { return }
                            Task { @MainActor [weak self] in
                                guard let self, var current = self.autoInstalling, current.id == id else { return }
                                // Keep stage progression monotonic across concurrent MainActor hops.
                                if stage.rawValue >= current.stage.rawValue {
                                    current.stage = stage
                                    current.fraction = max(stage == current.stage ? current.fraction : 0, fraction)
                                    current.canCancel = cancellable
                                    self.autoInstalling = current
                                }
                            }
                        }
                    }
                    self.activeSilentAttemptTask = attemptTask
                    _ = try await attemptTask.value
                    self.externalSilentTargets.removeValue(forKey: id)
                    self.markWaiting(id, false)
                    self.silentCancelledIDs.remove(id)
                    externalTarget?.onInstalled?()
                    self.autoInstalled = name
                    self.autoInstallNotice = AppText.text("已自动安装 \(name)")
                    self.notify(title: AppText.text("已自动安装"), body: name)
                } catch is CancellationError {
                    self.externalSilentTargets.removeValue(forKey: id)
                    self.markWaiting(id, false)
                    self.silentCancelledIDs.remove(id)
                    self.pendingAutoInstalls.removeAll { $0 == id }
                    self.pendingExternalAutoInstalls.removeAll { $0.id == id }
                    self.autoInstallFailed = nil
                    self.autoInstallCancelled = name
                    self.autoInstallNotice = AppText.text("已取消自动安装 \(name)")
                    InstallLog.shared.add("silent install cancelled: \(name)")
                } catch {
                    self.externalSilentTargets.removeValue(forKey: id)
                    self.silentCancelledIDs.remove(id)
                    self.autoInstallNotice = nil
                    self.autoInstallFailed = name
                    InstallLog.shared.add("silent install not finished: \(error.localizedDescription.prefix(160))")
                    if UIApplication.shared.applicationState == .active, self.autoInstall {
                        // In front and still failing (e.g. LocalDevVPN not connected): the sheet explains.
                        self.markWaiting(id, false)
                        if let externalTarget {
                            if !self.pendingExternalAutoInstalls.contains(where: { $0.id == externalTarget.id }) {
                                self.pendingExternalAutoInstalls.append(externalTarget)
                            }
                        } else if !self.pendingAutoInstalls.contains(id) {
                            self.pendingAutoInstalls.append(id)
                        }
                    } else {
                        // In the background iOS may simply have run out of time: retried when iPadn is back.
                        if let externalTarget {
                            if !self.pendingExternalAutoInstalls.contains(where: { $0.id == externalTarget.id }) {
                                self.pendingExternalAutoInstalls.append(externalTarget)
                            }
                        }
                        self.notify(title: AppText.text("自动安装未完成"), body: AppText.text("打开 iPadn 继续安装 \(name)"))
                    }
                }
            }
        }
    }

    private func notify(title: String, body: String) {
        guard notifications else { return }
        let content = UNMutableNotificationContent(); content.title = title; content.body = body; content.sound = .default
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil))
    }
    private func finishBackgroundIfReady() {
        guard !restoring, deliveries.isEmpty, processingIDs.isEmpty, removingIDs.isEmpty else { return }
        guard let completion = backgroundCompletion else { return }
        backgroundCompletion = nil
        // The app may be suspended right after this: finish pending saves first.
        persistQueue.sync {}
        completion()
    }
}

// Mac downloads are exported as original files. Never feed them to the IPA
// parser or iOS system installer. Reject encrypted or truncated fake PKGs.
enum MacPackageStorage {
    static func plausibleXARHeader(_ header: Data, fileSize: Int64) -> Bool {
        guard header.count >= 28, fileSize >= 29,
              header.prefix(4) == Data("xar!".utf8) else { return false }
        func number(_ offset: Int, length: Int) -> UInt64 {
            header[offset..<(offset + length)].reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
        }
        let headerSize = number(4, length: 2)
        let version = number(6, length: 2)
        let compressedTOC = number(8, length: 8)
        let uncompressedTOC = number(16, length: 8)
        // Cheap header sanity check; XARValidator performs the full TOC and
        // checksum verification afterwards.
        return headerSize >= 28 && headerSize <= 4096 && version == 1 &&
            compressedTOC > 0 && uncompressedTOC > 0 &&
            uncompressedTOC <= 32 * 1024 * 1024 &&
            headerSize < UInt64(fileSize) &&
            compressedTOC <= UInt64(fileSize) - headerSize
    }

    static func finish(staging: URL, job: DownloadJob) throws -> (String, StoreApp) {
        guard let format = job.rawFormat, ["dmg", "pkg", "zip"].contains(format),
              let length = (try FileManager.default.attributesOfItem(atPath: staging.path)[.size] as? NSNumber)?.int64Value,
              length >= 8 else { throw ToolError.message(AppText.text("下载的 Mac 文件不完整")) }
        let file = try FileHandle(forReadingFrom: staging)
        defer { try? file.close() }
        let prefix = try file.read(upToCount: 4) ?? Data()
        let valid: Bool
        switch format {
        case "pkg":
            try file.seek(toOffset: 0)
            let header = try file.read(upToCount: 28) ?? Data()
            guard plausibleXARHeader(header, fileSize: length) else { valid = false; break }
            // Inflate the TOC and verify every checksum before export, so an
            // encrypted or damaged package can never be offered as a PKG.
            _ = try XARValidator.validate(staging)
            valid = true
        case "zip": valid = prefix.starts(with: [0x50, 0x4B, 0x03, 0x04])
        default:
            guard length >= 512 else { throw ToolError.message(AppText.text("DMG 文件不完整")) }
            try file.seek(toOffset: UInt64(length - 512))
            valid = (try file.read(upToCount: 4) ?? Data()) == Data("koly".utf8)
        }
        guard valid else { throw ToolError.message(AppText.text("文件内容不是有效的 \(format.uppercased()) 安装包")) }
        let filename = "\(job.id.uuidString)-\(PackageService.safeName(job.app.name).prefix(40)).\(format)"
        let destination = LocalResources.packages.appendingPathComponent(filename)
        guard !FileManager.default.fileExists(atPath: destination.path) else {
            throw ToolError.message(AppText.text("同名安装包已存在"))
        }
        try FileManager.default.moveItem(at: staging, to: destination)
        var app = job.app
        app.size = length
        return (filename, app)
    }
}

extension DownloadManager: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask,
                               willPerformHTTPRedirection response: HTTPURLResponse,
                               newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        guard let url = request.url, url.scheme == "https",
              let host = url.host, !host.isEmpty, !Self.isLoopbackHost(host),
              url.user == nil, url.password == nil else { completionHandler(nil); return }
        completionHandler(request)
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let value = downloadTask.taskDescription, let id = UUID(uuidString: value) else { return }
        Task { @MainActor in
            guard let index = self.jobs.firstIndex(where: { $0.id == id }), self.jobs[index].status == .running,
                  self.accepts(downloadTask, id: id) else { return }
            let now = ProcessInfo.processInfo.systemUptime
            let finished = totalBytesExpectedToWrite > 0 && totalBytesWritten >= totalBytesExpectedToWrite
            guard finished || now - (self.progressPublishedAt[id] ?? 0) >= 0.25 else { return }
            self.progressPublishedAt[id] = now
            if var metric = self.transferMetrics[id] {
                metric.record(bytes: totalBytesWritten, at: now)
                self.transferMetrics[id] = metric
            } else { self.transferMetrics[id] = TransferMetrics(bytes: totalBytesWritten, sampledAt: now) }
            self.progress(for: id).bytes = (totalBytesWritten, max(0, totalBytesExpectedToWrite))
            // Resume data, not this count, is what a restart relies on.
            if Date().timeIntervalSince(self.lastSave) > 5 { self.persist() }
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        if downloadTask.taskDescription == Self.backgroundProbeDescription {
            // The service created the file; iPadn must also be able to read it.
            var unreadable = false
            do { _ = try Data(contentsOf: location) } catch { unreadable = Self.isPermissionError(error) }
            try? FileManager.default.removeItem(at: location)
            Task { @MainActor in self.finishBackgroundProbe(error: nil, unreadable: unreadable); self.finishBackgroundIfReady() }
            return
        }
        guard let value = downloadTask.taskDescription, let id = UUID(uuidString: value) else { return }
        deliveries.begin()
        LocalResources.ensureDirectoriesExist()
        let received = LocalResources.support.appendingPathComponent("\(id.uuidString)-\(UUID().uuidString).received")
        do {
            guard let response = downloadTask.response as? HTTPURLResponse, (200..<300).contains(response.statusCode) else {
                throw ToolError.message(AppText.text("下载失败（\((downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0)），请重试"))
            }
            if FileManager.default.fileExists(atPath: received.path) {
                try? FileManager.default.removeItem(at: received)
            }
            // Move synchronously: URLSession deletes its temporary file as soon as this delegate returns.
            do {
                try FileManager.default.moveItem(at: location, to: received)
            } catch {
                try FileManager.default.copyItem(at: location, to: received)
                try? FileManager.default.removeItem(at: location)
            }
            Task { @MainActor in
                let restoredDelivery = (self.loadingJobs || self.restoring) && session.configuration.identifier == Self.sessionID
                await self.startupTask?.value
                defer {
                    try? FileManager.default.removeItem(at: received)
                    self.updateBackgroundTask()
                    self.deliveries.end(); self.finishBackgroundIfReady()
                }
                // A transfer can finish while the app is not running; after a
                // relaunch the job may already read paused or queued with no task.
                guard let index = self.jobs.firstIndex(where: { $0.id == id }),
                      [.running, .pausing, .paused, .queued].contains(self.jobs[index].status),
                      self.accepts(downloadTask, id: id, restoredDelivery: restoredDelivery) else { return }
                do {
                    let destination = LocalResources.stagingURL(id)
                    try await Task.detached(priority: .userInitiated) {
                        let fm = FileManager()
                        try? fm.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
                        if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
                        do {
                            try fm.moveItem(at: received, to: destination)
                        } catch {
                            try fm.copyItem(at: received, to: destination)
                            try? fm.removeItem(at: received)
                        }
                    }.value
                } catch { self.fail(id, error: error); return }
                guard let updatedIndex = self.jobs.firstIndex(where: { $0.id == id }),
                      [.running, .pausing, .paused, .queued].contains(self.jobs[updatedIndex].status) else { return }
                self.tasks.removeValue(forKey: id)
                self.progressPublishedAt.removeValue(forKey: id)
                self.jobs[updatedIndex].status = .processing; self.persist(); self.schedule(); self.process(id)
            }
        } catch {
            try? FileManager.default.removeItem(at: received)
            let unreadable = Self.isPermissionError(error)
            Task { @MainActor in
                defer { self.deliveries.end(); self.finishBackgroundIfReady() }
                await self.startupTask?.value
                self.updateBackgroundTask()
                guard self.accepts(downloadTask, id: id) else { return }
                if unreadable, self.fallBackToForeground(id) { return }
                self.fail(id, error: error)
            }
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if task.taskDescription == Self.backgroundProbeDescription {
            if let error = error as NSError? {
                Task { @MainActor in self.finishBackgroundProbe(error: error); self.finishBackgroundIfReady() }
            }
            return
        }
        guard let error = error as NSError?, let value = task.taskDescription, let id = UUID(uuidString: value) else { return }
        deliveries.begin()
        let resume = error.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        Task { @MainActor in
            defer { self.deliveries.end(); self.finishBackgroundIfReady() }
            let restoredDelivery = (self.loadingJobs || self.restoring) && session.configuration.identifier == Self.sessionID
            await self.startupTask?.value
            guard let job = self.jobs.first(where: { $0.id == id }), job.status != .completed && job.status != .processing else { return }
            guard self.accepts(task, id: id, restoredDelivery: restoredDelivery) else { return }

            // Automatic fallback: if background nsurlsessiond failed to create file (-3000), retry in foreground process
            if error.domain == NSURLErrorDomain, error.code == NSURLErrorCannotCreateFile, self.fallBackToForeground(id) { return }

            // Save resume data first: it is what lets a cancelled transfer continue.
            if let resume = resume { try? resume.write(to: LocalResources.resumeURL(id), options: .atomic) }
            if job.status == .pausing || job.status == .paused { return }
            if error.domain == NSURLErrorDomain, error.code == NSURLErrorCancelled, resume != nil,
               let index = self.jobs.firstIndex(where: { $0.id == id }) {
                // Cancelled by the system (app quit, low storage): pause, keep progress.
                self.tasks.removeValue(forKey: id)
                self.progressPublishedAt.removeValue(forKey: id)
                self.updateBackgroundTask()
                self.jobs[index].status = .paused
                self.persist(); self.schedule()
                return
            }
            if resume == nil { try? FileManager.default.removeItem(at: LocalResources.resumeURL(id)) }
            self.fail(id, error: error)
        }
    }

    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor in
            await self.startupTask?.value
            self.finishBackgroundIfReady()
        }
    }
}
