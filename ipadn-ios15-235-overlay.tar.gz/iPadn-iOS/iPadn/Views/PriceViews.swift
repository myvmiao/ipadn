import SwiftUI
import UIKit

/// The app's price in each chosen storefront, converted for comparison.
struct RegionPriceView: View {
    @EnvironmentObject private var store: ToolStore
    let app: StoreApp
    @State private var prices: [RegionPrice] = []
    @State private var rates: ExchangeRates?
    @State private var loading = true
    @State private var showSpinner = false
    @State private var editingRegions = false
    @State private var inApps: [String: [InAppPrice]] = [:]
    @State private var inAppsLoading = false
    @State private var inAppNames: [String: String] = [:]
    /// Bumped to reload: on opening, after the region list was edited, on pull to refresh.
    @State private var reload = 0
    /// The latest load; an older one that finishes late changes nothing.
    @State private var generation = 0
    @State private var loadedRegions: [String] = []
    static let currencies = ["CNY", "HKD", "TWD", "USD", "JPY", "KRW", "EUR", "GBP", "SGD", "AUD", "CAD", "TRY"]

    private var base: String { store.settings.baseCurrency }
    private func cheapest(in sorted: [RegionPrice]) -> String? {
        sorted.first { item in item.price.map { $0 > 0 && rates?.convert($0, from: item.currency) != nil } == true }?.country
    }

    var body: some View {
        let sorted = PriceComparison.sorted(prices, rates: rates)
        let cheapest = cheapest(in: sorted)
        return List {
            Section {
                if prices.isEmpty && loading {
                    ForEach(0..<min(4, max(1, store.settings.priceRegions.count)), id: \.self) { _ in RegionPriceSkeleton() }
                } else if prices.isEmpty {
                    Text("暂时无法读取价格，请下拉重试。").foregroundStyle(.secondary)
                }
                ForEach(sorted) { item in
                    RegionPriceRow(item: item, rates: rates, cheapest: item.country == cheapest)
                }
            } header: {
                HStack {
                    Text("应用价格")
                    Spacer()
                    if showSpinner { ProgressView().controlSize(.small) }
                }
            } footer: { Text(footnote) }
            inAppSection
        }
        .navigationTitle("多地区价格")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .compatibleTopBarTrailing) {
                Menu {
                    Picker("换算货币", selection: $store.settings.baseCurrency) {
                        ForEach(Self.currencies, id: \.self) { Text(currencyName($0)).tag($0) }
                    }
                    Button("选择对比地区", systemImage: "globe") { editingRegions = true }
                } label: {
                    Image(systemName: "slider.horizontal.3").frame(minWidth: 44, minHeight: 44)
                }
                .accessibilityLabel("比价设置")
            }
        }
        // Reloads once the region list is closed, not on every tap in it.
        .sheet(isPresented: $editingRegions, onDismiss: {
            if store.settings.priceRegions != loadedRegions { reload += 1 }
        }) {
            CompatStack { RegionSelectionView(selection: $store.settings.priceRegions) }
        }
        .revealAfterDelay(loading, into: $showSpinner)
        .task(id: reload) { await load() }
        .task(id: base) { rates = await ExchangeRates.load(base: base) }
        .refreshable { await load() }
    }

    /// Listed storefronts whose pages this network could not open.
    private var blocked: [String] {
        prices.filter { $0.listing != nil && inApps[$0.country] == nil && InAppPriceService.redirected.contains(app.id + "|" + $0.country) }
            .map(\.country)
    }

    private var groups: [InAppGroup] {
        let regions = prices.compactMap { item -> (country: String, currency: String, items: [InAppPrice])? in
            guard let items = inApps[item.country], !items.isEmpty else { return nil }
            return (item.country, item.currency, items)
        }
        return InAppPriceService.groups(regions, rates: rates)
    }

    @ViewBuilder private var inAppSection: some View {
        let list = groups
        if !list.isEmpty || inAppsLoading || !prices.isEmpty {
            Section {
                if list.isEmpty {
                    if inAppsLoading {
                        HStack(spacing: 10) { ProgressView(); Text("正在读取内购项目…").foregroundStyle(.secondary) }
                    } else {
                        Text(blocked.isEmpty || !inApps.isEmpty ? (inApps.isEmpty ? "暂时无法读取内购项目，请下拉重试。" : "App Store 没有列出这个应用的内购项目。")
                             : "没有读到内购项目。")
                            .foregroundStyle(.secondary)

                    }
                }
                ForEach(list) { group in InAppGroupRow(group: group, rates: rates, name: inAppNames[group.name] ?? group.name) }
                if !blocked.isEmpty && !inAppsLoading {
                    Label {
                        Text("当前网络打开\(blocked.map { StoreRegions.name($0) }.joined(separator: AppText.text("、")))的 App Store 页面时会被转到中国区，所以读不到这些地区的内购价格。可以在代理工具中让 apps.apple.com 走代理，再下拉刷新。")
                            .font(.subheadline).foregroundStyle(.secondary)
                    } icon: {
                        Image(systemName: "info.circle").foregroundStyle(.secondary)
                    }
                }
            } header: {
                HStack {
                    Text("内购项目")
                    Spacer()
                    if inAppsLoading && !list.isEmpty { ProgressView().controlSize(.small) }
                }
            } footer: {
                VStack(alignment: .leading, spacing: 6) {
                    if !list.isEmpty {
                        Text("App Store 每个地区最多列出 10 个热门内购项目。同名项目按价格分档，通常对应月度、年度等不同订阅。")
                    }
                }
            }
        }
    }

    private var footnote: String {
        var lines = [AppText.text("按\(currencyName(base))换算，从低到高排列。")]
        if let rates {
            lines.append(AppText.text("汇率为 \(rates.updated.formatted(date: .abbreviated, time: .omitted)) 的参考中间价，实际扣款以发卡银行为准。"))
        } else if !loading {
            lines.append(AppText.text("暂时无法获取汇率，仅显示当地价格。"))
        }
        if prices.contains(where: { StoreRegions.taxExcluded.contains($0.country) && $0.listing != nil }) {
            lines.append(AppText.text("美国、加拿大的标价不含销售税。"))
        }
        return lines.joined(separator: "\n")
    }

    private func currencyName(_ code: String) -> String {
        (AppText.locale.localizedString(forCurrencyCode: code) ?? code) + AppText.text("（\(code)）")
    }

    private func load() async {
        generation += 1
        let current = generation
        let regions = store.settings.priceRegions
        loadedRegions = regions
        loading = true
        let found = await PriceComparison.regionPrices(appID: app.id, countries: regions)
        guard current == generation else { return }
        withAnimation(.easeOut(duration: 0.2)) { prices = found }
        loading = false
        // In-app purchases come from each listed storefront's product page.
        inAppsLoading = true
        let listed = found.filter { $0.listing != nil }.map(\.country)
        let pages = await InAppPriceService.fetch(appID: app.id, countries: listed)
        guard current == generation else { return }
        withAnimation(.easeOut(duration: 0.2)) { inApps = pages }
        inAppsLoading = false
        // Matching uses the English names; show them in the system language.
        let names = await InAppPriceService.localizedNames(appID: app.id, english: pages)
        guard current == generation, !names.isEmpty else { return }
        withAnimation(.easeOut(duration: 0.2)) { inAppNames = names }
    }
}

struct RegionPriceRow: View {
    let item: RegionPrice
    let rates: ExchangeRates?
    var cheapest = false
    var body: some View {
        HStack(spacing: 12) {
            Text(StoreRegions.flag(item.country)).font(.title2).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(StoreRegions.name(item.country)).font(.body)
                    if cheapest { TagBadge(text: "最低", tint: .green) }
                }
                Text(local).font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            if let converted {
                Text(converted).font(.body.monospacedDigit().weight(.medium))
            }
        }
        .accessibilityElement(children: .combine)
    }
    private var local: String {
        guard item.listing != nil else { return AppText.text("未在该地区上架") }
        guard let price = item.price else { return AppText.text("价格未知") }
        let text = WatchService.format(price, currency: item.currency)
        return StoreRegions.taxExcluded.contains(item.country) && price > 0 ? text + AppText.text("（不含税）") : text
    }
    private var converted: String? {
        guard let price = item.price, price > 0, let rates, item.currency != rates.base,
              let value = rates.convert(price, from: item.currency) else { return nil }
        return "≈ " + WatchService.format(value, currency: rates.base)
    }
}

struct InAppGroupRow: View {
    let group: InAppGroup
    let rates: ExchangeRates?
    /// The purchase's name in the system language when known.
    var name: String
    var body: some View {
        DisclosureGroup {
            ForEach(Array(group.entries.enumerated()), id: \.offset) { index, entry in
                HStack(spacing: 12) {
                    Text(StoreRegions.flag(entry.country)).accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 6) {
                            Text(StoreRegions.name(entry.country))
                            if index == 0 && group.entries.count > 1 && converted(entry) != nil { TagBadge(text: "最低", tint: .green) }
                        }
                        Text(entry.item.text).font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    if let converted = converted(entry) { Text(converted).font(.body.monospacedDigit()) }
                }
                .accessibilityElement(children: .combine)
            }
        } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(name).foregroundStyle(.primary).lineLimit(2)
                    Text(group.tiers > 1 ? "第 \(group.tier + 1) 档 · \(group.entries.count) 个地区" : "\(group.entries.count) 个地区")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 8)
                if let cheapest = group.entries.first {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(converted(cheapest) ?? cheapest.item.text).font(.body.monospacedDigit().weight(.medium)).foregroundStyle(.primary)
                        Text(StoreRegions.flag(cheapest.country) + " " + StoreRegions.name(cheapest.country))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
    private func converted(_ entry: InAppGroup.Entry) -> String? {
        guard let price = entry.item.price, let rates, let value = rates.convert(price, from: entry.currency) else { return nil }
        return (entry.currency == rates.base ? "" : "≈ ") + WatchService.format(value, currency: rates.base)
    }
}

private struct RegionPriceSkeleton: View {
    var body: some View {
        HStack(spacing: 12) {
            Circle().fill(Color(.tertiarySystemFill)).frame(width: 28, height: 28)
            VStack(alignment: .leading, spacing: 6) {
                RoundedRectangle(cornerRadius: 4).fill(Color(.tertiarySystemFill)).frame(width: 90, height: 14)
                RoundedRectangle(cornerRadius: 4).fill(Color(.tertiarySystemFill)).frame(width: 60, height: 12)
            }
            Spacer()
        }
        .monochromeShimmer()
        .padding(.vertical, 4)
        .accessibilityHidden(true)
    }
}

/// Picks the storefronts to compare; chosen ones first.
struct RegionSelectionView: View {
    @Binding var selection: [String]
    @Environment(\.dismiss) private var dismiss
    @State private var search = ""
    private var others: [String] {
        StoreRegions.byName().filter { !selection.contains($0) && StoreRegions.matches($0, query: search) }
    }
    var body: some View {
        List {
            if search.isEmpty {
                Section {
                    ForEach(selection, id: \.self) { code in row(code, selected: true) }
                        .onMove { selection.move(fromOffsets: $0, toOffset: $1) }
                } header: { Text("已选 \(selection.count) 个地区") } footer: {
                    Text("关注的应用也会记录这些地区的价格变化。")
                }
            }
            Section(search.isEmpty ? "其他地区" : "搜索结果") {
                ForEach(search.isEmpty ? others : selection.filter { StoreRegions.matches($0, query: search) } + others,
                        id: \.self) { code in row(code, selected: selection.contains(code)) }
            }
        }
        .searchable(text: $search, prompt: "搜索地区")
        .navigationTitle("对比地区")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
    }
    private func row(_ code: String, selected: Bool) -> some View {
        Button {
            if selected {
                guard selection.count > 1 else { return }
                selection.removeAll { $0 == code }
            } else {
                selection.append(code)
            }
        } label: {
            HStack(spacing: 12) {
                Text(StoreRegions.flag(code)).accessibilityHidden(true)
                Text(StoreRegions.name(code)).foregroundStyle(.primary)
                Spacer()
                if selected { Image(systemName: "checkmark").foregroundStyle(.tint) }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

/// Manages which App Store regions appear in the Search page's storefront picker.
struct SearchRegionsView: View {
    @EnvironmentObject private var store: ToolStore
    @State private var search = ""

    private var selection: [String] { store.settings.searchRegions }
    private var selectedMatches: [String] {
        selection.filter { StoreRegions.matches($0, query: search) }
    }
    private var otherMatches: [String] {
        let chosen = Set(selection)
        return StoreRegions.byName().filter { !chosen.contains($0) && StoreRegions.matches($0, query: search) }
    }
    private var searchMatches: [String] {
        let chosen = Set(selection)
        let ranked: [(code: String, rank: Int, isSelected: Bool, name: String)] = StoreRegions.codes.compactMap { code in
            guard let rank = StoreRegions.matchRank(code, query: search) else { return nil }
            return (code, rank, chosen.contains(code), StoreRegions.name(code))
        }
        return ranked.sorted { lhs, rhs in
            if lhs.rank != rhs.rank { return lhs.rank < rhs.rank }
            if lhs.isSelected != rhs.isSelected { return lhs.isSelected && !rhs.isSelected }
            return lhs.name.localizedStandardCompare(rhs.name) == .orderedAscending
        }.map(\.code)
    }
    private var isDefault: Bool { selection == StoreRegions.defaultSearchRegions }

    var body: some View {
        List {
            if search.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Section {
                    ForEach(selection, id: \.self) { code in
                        regionRow(code, selected: true)
                    }
                    .onMove { offsets, destination in
                        store.settings.searchRegions.move(fromOffsets: offsets, toOffset: destination)
                    }
                } header: {
                    Text("已显示 \(selection.count) 个地区")
                } footer: {
                    Text("勾选后将在搜索页的商店地区菜单中显示，至少保留 1 个地区。")
                }

                Section("全部地区（\(otherMatches.count)）") {
                    ForEach(otherMatches, id: \.self) { code in
                        regionRow(code, selected: false)
                    }
                }
            } else {
                Section("搜索结果（\(searchMatches.count)）") {
                    if searchMatches.isEmpty {
                        Text("无匹配地区")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(searchMatches, id: \.self) { code in
                            regionRow(code, selected: selection.contains(code))
                        }
                    }
                }
            }
        }
        .toolPage()
        .searchable(text: $search, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索地区名称或代码")
        .navigationTitle("商店地区")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .compatibleTopBarTrailing) {
                Button("恢复默认") {
                    store.settings.searchRegions = StoreRegions.defaultSearchRegions
                    if !store.settings.searchRegions.contains(store.settings.store.country.uppercased()),
                       let first = store.settings.searchRegions.first {
                        store.settings.store.country = first
                    }
                    UX.feedback()
                }
                .disabled(isDefault)
                .accessibilityIdentifier("settings.search-regions.reset")
            }
        }
    }

    private func regionRow(_ code: String, selected: Bool) -> some View {
        Button {
            toggle(code, currentlySelected: selected)
        } label: {
            HStack(spacing: 12) {
                Text(StoreRegions.flag(code))
                    .accessibilityHidden(true)
                Text(StoreRegions.name(code))
                    .foregroundStyle(.primary)
                Text(verbatim: code)
                    .font(.caption.monospaced())
                    .foregroundStyle(.tertiary)
                Spacer()
                if selected {
                    Image(systemName: "checkmark")
                        .font(.body.weight(.semibold))
                        .foregroundStyle(.tint)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("settings.search-region." + code)
        .accessibilityAddTraits(selected ? .isSelected : [])
        .accessibilityRemoveTraits(selected ? [] : .isSelected)
    }

    private func toggle(_ code: String, currentlySelected: Bool) {
        if currentlySelected {
            guard store.settings.searchRegions.count > 1 else {
                UX.warning()
                return
            }
            store.settings.searchRegions.removeAll { $0 == code }
            if store.settings.store.country.uppercased() == code,
               let fallback = store.settings.searchRegions.first {
                store.settings.store.country = fallback
            }
            UX.feedback()
        } else {
            if !store.settings.searchRegions.contains(code) {
                store.settings.searchRegions.append(code)
            }
            UX.feedback()
        }
    }
}
