import SwiftUI
import UIKit
import QuartzCore

// Visual language modeled on the App Store with the iPadn monochrome accent:
// grouped backgrounds, capsule action buttons, ring progress, large titles.
enum UX {
    static func motion(_ reduceMotion: Bool) -> Animation? {
        reduceMotion ? nil : .spring(response: 0.38, dampingFraction: 0.9)
    }
    static let tint = Color.accentColor
    static let buttonTint = Color.accentColor
    static let onAccent = Color(uiColor: .systemBackground)
    /// The monochrome accent is near-white in dark mode, which would make an "on" switch
    /// track blend into its white thumb; switch to system green there.
    static let switchTint = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark ? .systemGreen : (UIColor(named: "AccentColor") ?? .label)
    })
    static let iconCorner: CGFloat = 0.2237
    @MainActor private static let selectionGenerator = UISelectionFeedbackGenerator()
    @MainActor private static let lightImpactGenerator = UIImpactFeedbackGenerator(style: .light)
    @MainActor private static let softImpactGenerator = UIImpactFeedbackGenerator(style: .soft)
    @MainActor private static let notificationGenerator = UINotificationFeedbackGenerator()
    @MainActor static func prepare() {
        selectionGenerator.prepare()
        lightImpactGenerator.prepare()
    }
    @MainActor static func feedback() {
        selectionGenerator.selectionChanged()
        selectionGenerator.prepare()
    }
    @MainActor static func tapLight() {
        lightImpactGenerator.impactOccurred(intensity: 0.72)
        lightImpactGenerator.prepare()
    }
    @MainActor static func tapSoft() {
        softImpactGenerator.impactOccurred(intensity: 0.6)
        softImpactGenerator.prepare()
    }
    @MainActor static func success() {
        notificationGenerator.notificationOccurred(.success)
        notificationGenerator.prepare()
    }
    @MainActor static func warning() {
        notificationGenerator.notificationOccurred(.warning)
        notificationGenerator.prepare()
    }
}

/// Full-width primary action (App Store sign-in "继续" style).
struct PrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.semibold))
            .foregroundStyle(configuration.role == .destructive ? Color.white : UX.onAccent)
            .padding(.horizontal, 16).padding(.vertical, 14)
            .background((configuration.role == .destructive ? Color.red : UX.buttonTint).opacity(configuration.isPressed ? 0.8 : 1),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .opacity(enabled ? 1 : 0.35)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.98 : 1)
            .animation(reduceMotion ? nil : .compatibleSnappy(duration: 0.15), value: configuration.isPressed)
            .compatibleOnChange(of: configuration.isPressed) { down in if down { UX.prepare() } }
    }
}
typealias MonochromeButtonStyle = PrimaryButtonStyle

/// System switch with a tint that stays legible in both appearances (see `UX.switchTint`).
struct TintedSwitchToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        Toggle(configuration).toggleStyle(.switch).tint(UX.switchTint)
    }
}

private struct CapsuleAppearanceModifier: ViewModifier {
    let filled: Bool
    let pressed: Bool
    let enabled: Bool
    let suppressesPress: Bool
    let pressScale: CGFloat
    let pressOpacity: Double
    var managesPressAndEnabled = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func body(content: Content) -> some View {
        let down = pressed && !suppressesPress
        content
            .environment(\.isEnabled, enabled || suppressesPress)
            .font(.subheadline.weight(.bold))
            .lineLimit(1)
            // Capsule labels ("Download", "Get") must never be clipped.
            .fixedSize(horizontal: true, vertical: false)
            .foregroundStyle(filled ? UX.onAccent : UX.tint)
            .padding(.horizontal, 16).frame(minWidth: 74, minHeight: 30)
            .background(filled ? AnyShapeStyle(UX.tint) : AnyShapeStyle(Color(.tertiarySystemFill)), in: Capsule())
            .opacity(managesPressAndEnabled ? (down ? pressOpacity : enabled || suppressesPress ? 1 : 0.4) : 1)
            .scaleEffect(managesPressAndEnabled && down && !reduceMotion ? pressScale : 1)
            .animation(managesPressAndEnabled && !reduceMotion ? .compatibleSnappy(duration: 0.14) : nil, value: down)
            .contentShape(Capsule())
    }
}

/// Shared touch-down tracker so custom UIKit tap targets highlight on finger-down
/// while cancelling cleanly during list scroll or horizontal swipe gestures.
final class TactileContainerView: UIView {
    var onPressChange: ((Bool) -> Void)?
    private var pressed = false

    private func setPressed(_ down: Bool) {
        guard pressed != down else { return }
        pressed = down
        if down { UX.prepare() }
        onPressChange?(down)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        setPressed(true)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        setPressed(bounds.insetBy(dx: -12, dy: -12).contains(touch.location(in: self)))
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        setPressed(false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        setPressed(false)
    }
}

private struct TactileTapOverlay: UIViewRepresentable {
    let enabled: Bool
    let onPressChange: (Bool) -> Void
    let onTap: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> TactileContainerView {
        let view = TactileContainerView()
        view.backgroundColor = .clear
        view.isOpaque = false
        view.isAccessibilityElement = false
        view.onPressChange = { [weak coordinator = context.coordinator] down in
            coordinator?.handlePressChange(down)
        }
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped))
        tap.cancelsTouchesInView = true
        tap.delaysTouchesBegan = false
        tap.delaysTouchesEnded = false
        tap.delegate = context.coordinator
        view.addGestureRecognizer(tap)
        return view
    }

    func updateUIView(_ uiView: TactileContainerView, context: Context) {
        context.coordinator.parent = self
        uiView.isUserInteractionEnabled = enabled
    }

    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var parent: TactileTapOverlay
        init(parent: TactileTapOverlay) { self.parent = parent }

        func handlePressChange(_ down: Bool) {
            parent.onPressChange(down)
        }

        @objc func tapped() {
            guard parent.enabled else { return }
            parent.onTap()
        }

        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            parent.enabled
        }
    }
}

private struct TactileNavigationTapModifier: ViewModifier {
    let enabled: Bool
    let pressScale: CGFloat
    let pressOpacity: Double
    let onTap: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.revealSuppressesPress) private var suppressesPress
    @State private var pressed = false
    @State private var downAt: CFTimeInterval = 0
    @State private var pulseClearWork: DispatchWorkItem?

    func body(content: Content) -> some View {
        let active = pressed && enabled && !suppressesPress
        content
            .opacity(active ? pressOpacity : (enabled || suppressesPress ? 1 : 0.4))
            .scaleEffect(active && !reduceMotion ? pressScale : 1)
            .animation(reduceMotion ? nil : .compatibleSnappy(duration: 0.14), value: active)
            .overlay {
                TactileTapOverlay(
                    enabled: enabled && !suppressesPress,
                    onPressChange: { down in
                        if down {
                            pulseClearWork?.cancel()
                            pulseClearWork = nil
                            downAt = CACurrentMediaTime()
                            pressed = true
                        } else if pulseClearWork == nil {
                            pressed = false
                        }
                    },
                    onTap: {
                        let elapsed = downAt > 0 ? CACurrentMediaTime() - downAt : 0
                        downAt = 0
                        if !reduceMotion && elapsed < 0.06 {
                            pulseClearWork?.cancel()
                            pressed = true
                            let work = DispatchWorkItem {
                                pulseClearWork = nil
                                pressed = false
                            }
                            pulseClearWork = work
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08, execute: work)
                        } else {
                            pressed = false
                        }
                        onTap()
                    }
                )
            }
    }
}

extension View {
    /// Scroll-safe, swipe-safe tap control for buttons nested inside a List `NavigationLink`.
    func tactileNavigationTap(enabled: Bool = true, pressScale: CGFloat = 0.94, pressOpacity: Double = 0.72,
                              onTap: @escaping () -> Void) -> some View {
        modifier(TactileNavigationTapModifier(enabled: enabled, pressScale: pressScale, pressOpacity: pressOpacity, onTap: onTap))
    }
}

/// App Store "获取 / 打开" capsule. `filled` is the prominent variant.
struct CapsuleButtonStyle: ButtonStyle {
    var filled = false
    @Environment(\.isEnabled) private var enabled
    @Environment(\.revealSuppressesPress) private var suppressesPress
    func makeBody(configuration: Configuration) -> some View {
        let pressed = configuration.isPressed && !suppressesPress
        configuration.label
            .modifier(CapsuleAppearanceModifier(filled: filled, pressed: pressed, enabled: enabled,
                                              suppressesPress: suppressesPress, pressScale: 0.94, pressOpacity: 0.72))
            .compatibleOnChange(of: pressed) { down in if down { UX.prepare() } }
    }
}

/// Primary row action pill: native `Button` outside `NavigationLink`, or
/// scroll-safe UIKit tap overlay inside a `NavigationLink` row so tapping
/// "Get" doesn't also push the detail page.
struct RowCapsule: View {
    let title: LocalizedStringKey
    var filled = false
    var enabled = true
    var insideNavigationLink = false
    var haptic = true
    let action: () -> Void
    @Environment(\.revealSuppressesPress) private var suppressesPress
    var body: some View {
        if insideNavigationLink {
            Text(title)
                .modifier(CapsuleAppearanceModifier(filled: filled, pressed: false, enabled: enabled,
                                                  suppressesPress: suppressesPress, pressScale: 1, pressOpacity: 1,
                                                  managesPressAndEnabled: false))
                .tactileNavigationTap(enabled: enabled) {
                    if haptic { UX.tapLight() }
                    action()
                }
                .accessibilityElement(children: .ignore)
                .accessibilityAddTraits(.isButton)
                .accessibilityLabel(title)
                .accessibilityAction {
                    if enabled {
                        if haptic { UX.tapLight() }
                        action()
                    }
                }
        } else {
            Button {
                if haptic { UX.tapLight() }
                action()
            } label: {
                Text(title)
            }
            .buttonStyle(CapsuleButtonStyle(filled: filled))
            .disabled(!enabled)
            .accessibilityLabel(title)
        }
    }
}

/// App Store button display state for pill-to-ring morph animations.
enum AppStoreActionPhase: Equatable {
    case capsule(title: String, filled: Bool = false, enabled: Bool = true)
    case cloud(enabled: Bool = true)
    case loading
    case downloading(Double)
    case processing
    case completedCheck

    var isCircular: Bool {
        switch self {
        case .loading, .downloading, .processing, .completedCheck: return true
        case .capsule, .cloud: return false
        }
    }

    var isCloud: Bool {
        if case .cloud = self { return true }
        return false
    }

    var isProcessing: Bool {
        if case .processing = self { return true }
        return false
    }

    var isCompletedCheck: Bool {
        if case .completedCheck = self { return true }
        return false
    }

    var isEnabled: Bool {
        switch self {
        case .capsule(_, _, let enabled), .cloud(let enabled): return enabled
        case .loading, .downloading, .processing, .completedCheck: return true
        }
    }
}

struct PillButtonPressStyle: ButtonStyle {
    let scale: CGFloat
    let opacity: Double
    @Environment(\.isEnabled) private var enabled
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.revealSuppressesPress) private var suppressesPress
    func makeBody(configuration: Configuration) -> some View {
        let pressed = configuration.isPressed && !suppressesPress
        configuration.label
            .opacity(pressed ? opacity : (enabled || suppressesPress ? 1 : 0.4))
            .scaleEffect(pressed && !reduceMotion ? scale : 1)
            .animation(reduceMotion ? nil : .compatibleSnappy(duration: 0.14), value: pressed)
            .compatibleOnChange(of: pressed) { down in if down { UX.prepare() } }
    }
}

/// Monochrome App Store action control that smoothly morphs a capsule button into
/// a rotating open arc while loading and a clockwise progress ring while downloading.
struct AppStoreActionButton: View {
    let phase: AppStoreActionPhase
    var alignment: Alignment = .center
    var insideNavigationLink = false
    var showsStopSquare = true
    var ringSymbol = "pause.fill"
    var usesSpinningProcessingRing = false
    var accessibilityLabelText: String? = nil
    var accessibilityValueText: String? = nil
    let action: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.revealSuppressesPress) private var suppressesPress

    @State private var lastTitle = "获取"
    @State private var lastFilled = false
    @State private var pillWidth: CGFloat = 74
    @State private var pillHeight: CGFloat = 30

    private var morphAnimation: Animation? {
        reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.84)
    }

    private var isCircular: Bool { phase.isCircular }
    private var ringSize: CGFloat { max(30, dynamicTypeSize.isAccessibilitySize ? min(36, pillHeight) : 30) }
    private var slotMinWidth: CGFloat { max(74, pillWidth) }
    private var activeTitle: String {
        if case .capsule(let title, _, _) = phase, !title.isEmpty { return title }
        return lastTitle
    }
    private var activeFilled: Bool {
        if case .capsule(_, let filled, _) = phase { return filled }
        return lastFilled
    }
    private var ringProgress: Double? {
        switch phase {
        case .downloading(let fraction): return fraction
        case .loading, .processing, .completedCheck: return nil
        case .capsule, .cloud: return nil
        }
    }
    private var targetWidth: CGFloat {
        if isCircular { return ringSize }
        if phase.isCloud { return max(34, ringSize) }
        return max(74, pillWidth)
    }
    private var targetHeight: CGFloat {
        if isCircular { return ringSize }
        if phase.isCloud { return max(30, ringSize) }
        return max(30, pillHeight)
    }

    @ViewBuilder private var morphBody: some View {
        let circular = isCircular
        let cloud = phase.isCloud
        let completedCheck = phase.isCompletedCheck
        let processingRing = usesSpinningProcessingRing && phase.isProcessing
        let showPill = !circular && !cloud
        ZStack {
            ZStack {
                Capsule()
                    .fill(activeFilled ? AnyShapeStyle(UX.tint) : AnyShapeStyle(Color(.tertiarySystemFill)))
                    .opacity(showPill ? 1 : 0)
                    .animation(
                        reduceMotion
                            ? nil
                            : (showPill ? .easeOut(duration: 0.18).delay(0.05) : .easeOut(duration: 0.12)),
                        value: showPill
                    )
                    .animation(reduceMotion ? nil : .easeInOut(duration: 0.20), value: activeFilled)

                Text(LocalizedStringKey(activeTitle))
                    .font(.subheadline.weight(.bold))
                    .lineLimit(1)
                    .fixedSize(horizontal: true, vertical: false)
                    .minimumScaleFactor(dynamicTypeSize.isAccessibilitySize ? 0.75 : 1.0)
                    .foregroundStyle(activeFilled ? UX.onAccent : UX.tint)
                    .padding(.horizontal, 16)
                    .opacity(showPill ? 1 : 0)
                    .scaleEffect(showPill || reduceMotion ? 1 : 0.72)
                    .animation(
                        reduceMotion
                            ? nil
                            : (showPill ? .easeOut(duration: 0.18).delay(0.08) : .easeOut(duration: 0.10)),
                        value: showPill
                    )
                    .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: activeTitle)
            }
            .frame(width: targetWidth, height: targetHeight)
            .clipShape(Capsule())
            .animation(morphAnimation, value: circular)
            .animation(morphAnimation, value: cloud)

            Image(systemName: "icloud.and.arrow.down")
                .font(.title3.weight(.medium))
                .foregroundStyle(UX.tint)
                .opacity(cloud ? 1 : 0)
                .scaleEffect(cloud || reduceMotion ? 1 : 0.6)
                .animation(
                    reduceMotion
                        ? nil
                        : (cloud ? .easeOut(duration: 0.16).delay(0.06) : .easeOut(duration: 0.10)),
                    value: cloud
                )

            if circular {
                Group {
                    if completedCheck {
                        CompletionRing(outerPadding: 0)
                    } else if processingRing {
                        SpinningRing(outerPadding: 0)
                    } else {
                        ProgressRing(
                            progress: ringProgress,
                            symbol: ringSymbol,
                            showsStopSquare: showsStopSquare,
                            size: ringSize,
                            outerPadding: 0
                        )
                    }
                }
                .transition(
                    reduceMotion
                        ? .opacity
                        : .asymmetric(
                            insertion: .opacity
                                .combined(with: .scale(scale: 0.76))
                                .animation(.spring(response: 0.30, dampingFraction: 0.82).delay(0.05)),
                            removal: .opacity
                                .combined(with: .scale(scale: 0.74))
                                .animation(.easeIn(duration: 0.10))
                        )
                )
            }
        }
        .frame(width: targetWidth, height: targetHeight)
        .animation(morphAnimation, value: circular)
        .animation(morphAnimation, value: cloud)
        .animation(morphAnimation, value: completedCheck)
        .animation(morphAnimation, value: processingRing)
        .background {
            Text(LocalizedStringKey(activeTitle))
                .font(.subheadline.weight(.bold))
                .lineLimit(1)
                .minimumScaleFactor(dynamicTypeSize.isAccessibilitySize ? 0.75 : 1.0)
                .fixedSize(horizontal: true, vertical: false)
                .padding(.horizontal, 16)
                .frame(minWidth: 74, minHeight: 30)
                .hidden()
                .accessibilityHidden(true)
                .compatibleOnGeometryChange(for: CGSize.self) { $0.size } action: { size in
                    let nextWidth = max(74, size.width.rounded(.up))
                    let nextHeight = max(30, size.height.rounded(.up))
                    if size.width > 0, abs(nextWidth - pillWidth) > 0.5 { pillWidth = nextWidth }
                    if size.height > 0, abs(nextHeight - pillHeight) > 0.5 { pillHeight = nextHeight }
                }
        }
        .frame(minWidth: slotMinWidth, minHeight: 36, alignment: alignment)
        .animation(morphAnimation, value: slotMinWidth)
        .contentShape(Rectangle())
        .onAppear { syncCachedCapsule(phase) }
        .compatibleOnChange(of: phase) { next in syncCachedCapsule(next) }
    }

    private func syncCachedCapsule(_ current: AppStoreActionPhase) {
        if case .capsule(let title, let filled, _) = current {
            lastTitle = title
            lastFilled = filled
        }
    }

    private var accessibleLabel: Text {
        accessibilityLabelText.map { Text(verbatim: $0) } ?? Text(LocalizedStringKey(activeTitle))
    }

    var body: some View {
        let enabled = phase.isEnabled
        if insideNavigationLink {
            morphBody
                .tactileNavigationTap(
                    enabled: enabled && !suppressesPress,
                    pressScale: isCircular ? 0.90 : 0.94,
                    pressOpacity: isCircular ? 0.65 : 0.72
                ) {
                    UX.tapLight()
                    action()
                }
                .accessibilityElement(children: .ignore)
                .accessibilityAddTraits(.isButton)
                .accessibilityLabel(accessibleLabel)
                .accessibilityValue(Text(accessibilityValueText ?? ""))
                .accessibilityAction {
                    guard enabled else { return }
                    UX.tapLight()
                    action()
                }
        } else {
            Button {
                UX.tapLight()
                action()
            } label: {
                morphBody
            }
            .buttonStyle(PillButtonPressStyle(scale: isCircular ? 0.90 : 0.94, opacity: isCircular ? 0.65 : 0.72))
            .disabled(!enabled)
            .accessibilityLabel(accessibleLabel)
            .accessibilityValue(Text(accessibilityValueText ?? ""))
        }
    }
}

/// App Store download progress: an open monochrome spinning arc while waiting,
/// or a clockwise circular progress ring with a stop/pause glyph inside.
struct ProgressRing: View {
    var progress: Double?
    var symbol = "pause.fill"
    var showsStopSquare = false
    var size: CGFloat = 30
    var trackLineWidth: CGFloat = 3.0
    var guideLineWidth: CGFloat = 3.0
    var outerPadding: CGFloat = 7
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    /// Keeps strokes inside `size × size` so surrounding `Capsule()` morph clips never slice the ring in half.
    private var strokeInset: CGFloat {
        max(trackLineWidth, guideLineWidth) / 2
    }

    var body: some View {
        ZStack {
            Circle()
                .inset(by: strokeInset)
                .stroke(UX.tint.opacity(0.18), lineWidth: guideLineWidth)
                .opacity(progress == nil ? 0 : 1)
                .animation(reduceMotion ? nil : .easeOut(duration: 0.2), value: progress == nil)
            if let progress {
                Circle()
                    .inset(by: strokeInset)
                    .trim(from: 0, to: max(0.02, min(1, progress)))
                    .stroke(UX.tint, style: StrokeStyle(lineWidth: trackLineWidth, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(reduceMotion ? nil : .linear(duration: 0.25), value: progress)
                if showsStopSquare {
                    RoundedRectangle(cornerRadius: 2.2, style: .continuous)
                        .fill(UX.tint)
                        .frame(width: 9, height: 9)
                        .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.6)))
                } else {
                    Image(systemName: symbol).font(.system(size: 10, weight: .bold)).foregroundStyle(UX.tint)
                        .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.6)))
                }
            } else {
                TimelineView(.animation(minimumInterval: nil, paused: reduceMotion)) { timeline in
                    let period = 0.85
                    let fraction = reduceMotion
                        ? 0.0
                        : timeline.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: period) / period
                    Circle()
                        .inset(by: strokeInset)
                        .trim(from: 0, to: 0.78)
                        .stroke(UX.tint, style: StrokeStyle(lineWidth: trackLineWidth, lineCap: .round))
                        .rotationEffect(.degrees(fraction * 360 - 90))
                }
                .transition(.opacity)
            }
        }
        .animation(reduceMotion ? nil : .spring(response: 0.30, dampingFraction: 0.86), value: progress == nil)
        .frame(width: size, height: size)
        .padding(outerPadding)
        .contentShape(Circle())
    }
}

/// The ring while a finished download is checked and prepared: an arc that
/// keeps turning on the same track, so the ring never disappears mid-task.
struct SpinningRing: View {
    var outerPadding: CGFloat = 7
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var turning = false
    var body: some View {
        ZStack {
            Circle().stroke(Color(.tertiarySystemFill), lineWidth: 3)
            Circle().trim(from: 0, to: 0.28)
                .stroke(UX.tint, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                .rotationEffect(.degrees(turning ? 270 : -90))
                .animation(reduceMotion ? nil : .linear(duration: 0.9).repeatForever(autoreverses: false), value: turning)
        }
        .frame(width: 30, height: 30)
        .padding(outerPadding)
        .onAppear { turning = true }
    }
}

/// Telegram's finished state: the ring closes and a check draws inside it.
struct CompletionRing: View {
    var outerPadding: CGFloat = 7
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var ring: CGFloat = 0.28
    @State private var check: CGFloat = 0
    @State private var pop: CGFloat = 1
    var body: some View {
        ZStack {
            Circle().stroke(Color(.tertiarySystemFill), lineWidth: 3)
            Circle().trim(from: 0, to: ring)
                .stroke(Color.green, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                .rotationEffect(.degrees(-90))
            CheckShape().trim(from: 0, to: check)
                .stroke(Color.green, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                .frame(width: 13, height: 10)
        }
        .frame(width: 30, height: 30)
        .scaleEffect(pop)
        .padding(outerPadding)
        .onAppear {
            guard !reduceMotion else { ring = 1; check = 1; return }
            withAnimation(.easeOut(duration: 0.25)) { ring = 1 }
            withAnimation(.easeOut(duration: 0.2).delay(0.2)) { check = 1 }
            withAnimation(.spring(response: 0.25, dampingFraction: 0.5).delay(0.35)) { pop = 1.12 }
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7).delay(0.5)) { pop = 1 }
        }
        .accessibilityLabel("下载完成")
    }
}

struct CheckShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.minX + rect.width * 0.36, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        return path
    }
}

struct BrandMark: View {
    var size: CGFloat = 40
    var body: some View {
        Image("BrandMark").resizable().scaledToFit().frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * UX.iconCorner, style: .continuous)).accessibilityHidden(true)
    }
}

struct EmptyState: View {
    let title: LocalizedStringKey
    let message: LocalizedStringKey
    let symbol: String
    var actionTitle: LocalizedStringKey? = nil
    var action: (() -> Void)? = nil
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: symbol).font(.system(size: 44, weight: .light)).foregroundStyle(.secondary)
                .padding(.bottom, 6)
            Text(title).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
            Text(message).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            if let actionTitle, let action {
                Button(actionTitle, action: action).buttonStyle(CapsuleButtonStyle()).padding(.top, 8)
            }
        }.padding(.vertical, 28).frame(maxWidth: .infinity).padding(.horizontal, 12)
    }
}

struct InlineIssue: View {
    /// Already in its final language: service errors and store state arrive as text.
    let message: String
    var retry: (() -> Void)? = nil
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange).font(.title3)
            VStack(alignment: .leading, spacing: 8) {
                Text(message).font(.subheadline).fixedSize(horizontal: false, vertical: true)
                if let retry { Button("重试", action: retry).buttonStyle(CapsuleButtonStyle()) }
            }
        }.padding(.vertical, 6)
    }
}

/// In-list search field. `capsule` is the App Store search-tab bar: a
/// full-width pill that searches from the keyboard's Search key.
struct SearchInput: View {
    @Binding var text: String
    var placeholder: LocalizedStringKey
    var capsule = false
    var submit: (() -> Void)? = nil
    var clear: (() -> Void)? = nil
    @FocusState private var focused: Bool
    private var trimmed: String { text.trimmingCharacters(in: .whitespacesAndNewlines) }
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField(placeholder, text: $text).textInputAutocapitalization(.never).autocorrectionDisabled()
                .submitLabel(.search).focused($focused)
                .onSubmit { focused = false; if !trimmed.isEmpty { submit?() } }
                .accessibilityLabel(placeholder)
            if !text.isEmpty {
                Button { text = ""; clear?() } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.tertiary).frame(width: 32, height: 32) }
                    .buttonStyle(.borderless).accessibilityLabel("清空输入")
            }
            if submit != nil && !capsule {
                Button { focused = false; submit?() } label: { Text("搜索").font(.subheadline.weight(.semibold)) }
                    .buttonStyle(.borderless)
                    .disabled(trimmed.isEmpty)
                    .accessibilityLabel("搜索应用").accessibilityIdentifier("search.submit")
            }
        }
        .padding(.leading, capsule ? 14 : 10).padding(.trailing, capsule ? 6 : 8)
        .frame(minHeight: capsule ? 44 : 40)
        .background(Color(.tertiarySystemFill), in: RoundedRectangle(cornerRadius: capsule ? 22 : 10, style: .continuous))
        .contentShape(Rectangle())
        .onTapGesture { focused = true }
    }
}

/// A section header's 刷新 that turns into a small spinner while busy, in
/// the same place, so nothing around it moves. Taps while busy are ignored.
struct RefreshButton: View {
    let busy: Bool
    let action: () -> Void
    @State private var showsSpinner = false
    var body: some View {
        ZStack(alignment: .trailing) {
            Button("刷新") { if !busy { action() } }
                .font(.body).textCase(nil)
                .opacity(showsSpinner ? 0 : 1)
            if showsSpinner { ProgressView().controlSize(.small).transition(.opacity) }
        }
        .revealAfterDelay(busy, into: $showsSpinner)
        .accessibilityValue(busy ? "正在刷新" : "")
    }
}

/// Root-tab chrome that pairs with `PageHeader`. The navigation bar stays
/// visible (hiding it made the page jump when popping back from a pushed
/// page); it shows the small title only once the header has scrolled away.
struct RootTabBar: ViewModifier {
    let title: LocalizedStringKey
    let headerScrolledAway: Bool
    func body(content: Content) -> some View {
        content
            .compatibleVerticalContentMargin(.top, 0)
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text(title).font(.headline)
                        .opacity(headerScrolledAway ? 1 : 0)
                        .animation(.easeInOut(duration: 0.18), value: headerScrolledAway)
                        .accessibilityHidden(!headerScrolledAway)
                }
            }
    }
}
private struct ScrolledUnderBarModifier: ViewModifier {
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    let action: (Bool) -> Void
    func body(content: Content) -> some View {
        let threshold: CGFloat = verticalSizeClass == .compact ? 52 : 104
        content.compatibleOnGeometryChange(for: Bool.self) { proxy in
            proxy.frame(in: .global).maxY < threshold
        } action: { action($0) }
    }
}

extension View {
    /// Sets `shown` once `active` has lasted a moment and clears it as soon
    /// as it ends, so quick work (a cache hit) never flashes a spinner.
    func revealAfterDelay(_ active: Bool, into shown: Binding<Bool>, delay: TimeInterval = 0.3) -> some View {
        task(id: active) {
            guard active else {
                if shown.wrappedValue { withAnimation(.easeOut(duration: 0.15)) { shown.wrappedValue = false } }
                return
            }
            try? await compatSleep(seconds: delay)
            guard !Task.isCancelled else { return }
            withAnimation(.easeIn(duration: 0.15)) { shown.wrappedValue = true }
        }
    }
    func rootTabBar(_ title: LocalizedStringKey, headerScrolledAway: Bool) -> some View {
        modifier(RootTabBar(title: title, headerScrolledAway: headerScrolledAway))
    }
    /// Reports whether this view has scrolled up under the navigation bar.
    func onScrolledUnderBar(_ action: @escaping (Bool) -> Void) -> some View {
        modifier(ScrolledUnderBarModifier(action: action))
    }
}

/// App Store root-tab header: large title with the trailing control (the
/// account avatar) on the same line, instead of a separate toolbar row.
struct PageHeader<Trailing: View>: View {
    let title: LocalizedStringKey
    @ViewBuilder var trailing: Trailing
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Text(title).font(.largeTitle.weight(.bold)).lineLimit(1).minimumScaleFactor(0.7)
                .accessibilityAddTraits(.isHeader)
            Spacer(minLength: 0)
            trailing
        }
    }
}
extension PageHeader where Trailing == EmptyView {
    init(title: LocalizedStringKey) { self.init(title: title) { EmptyView() } }
}

struct TaskStatusPill: View {
    let status: DownloadStatus
    private var color: Color {
        switch status {
        case .failed: return .red
        case .completed: return .green
        case .paused: return .secondary
        default: return UX.tint
        }
    }
    var body: some View {
        // Not a Label: inside List rows a Label gets the list's icon column,
        // which leaves a wide gap between the glyph and the text.
        HStack(spacing: 4) {
            Image(systemName: status.symbol).imageScale(.small).accessibilityHidden(true)
            Text(status.title)
        }
        .font(.caption.weight(.semibold))
        .foregroundStyle(color)
        .accessibilityElement(children: .combine)
    }
}

/// Small outlined capsule for platform and state tags (iOS, 已下架…).
struct TagBadge: View {
    let text: LocalizedStringKey
    var tint: Color = .secondary
    var body: some View {
        Text(text)
            .font(.caption2.weight(.semibold))
            .textCase(nil)
            .foregroundStyle(tint)
            .lineLimit(1)
            .padding(.horizontal, 7).padding(.vertical, 2)
            .background(tint.opacity(0.1), in: Capsule())
            .overlay(Capsule().stroke(tint.opacity(0.35), lineWidth: 0.5))
            .fixedSize()
    }
}

/// Monochrome 3-blade TestFlight propeller glyph matching the platform icon slot on list rows.
private struct TestFlightPropellerShape: Shape {
    func path(in rect: CGRect) -> Path {
        let cx = rect.midX
        let cy = rect.midY
        let r = min(rect.width, rect.height) * 0.5
        var path = Path()

        let hubR = r * 0.17
        path.addEllipse(in: CGRect(x: cx - hubR, y: cy - hubR, width: hubR * 2, height: hubR * 2))

        let angles: [Double] = [-.pi / 2, .pi / 6, 5 * .pi / 6]
        for angle in angles {
            var blade = Path()
            let baseW = r * 0.11
            let midW = r * 0.21
            let tipR = r * 0.96
            let midR = r * 0.64

            blade.move(to: CGPoint(x: -baseW, y: 0))
            blade.addCurve(
                to: CGPoint(x: 0, y: -tipR),
                control1: CGPoint(x: -midW, y: -midR * 0.62),
                control2: CGPoint(x: -midW * 0.85, y: -tipR * 0.96)
            )
            blade.addCurve(
                to: CGPoint(x: baseW, y: 0),
                control1: CGPoint(x: midW * 0.85, y: -tipR * 0.96),
                control2: CGPoint(x: midW, y: -midR * 0.62)
            )
            blade.closeSubpath()

            let transform = CGAffineTransform(translationX: cx, y: cy)
                .rotated(by: CGFloat(angle + .pi / 2))
            path.addPath(blade, transform: transform)
        }
        return path
    }
}

/// Compact monochrome TestFlight squircle icon aligned to the metadata platform glyph slot.
struct TestFlightIcon: View {
    var size: CGFloat = 15
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .fill(Color.secondary.opacity(0.85))
            TestFlightPropellerShape()
                .fill(.black)
                .padding(size * 0.16)
                .blendMode(.destinationOut)
        }
        .compositingGroup()
        .frame(width: size, height: size)
        .accessibilityLabel("TestFlight")
    }
}

/// Compact monochrome client-platform icon paired beside `TestFlightIcon` or package metadata.
struct PlatformGlyph: View {
    let platform: String
    var size: CGFloat = 14

    static func symbol(for platform: String) -> String {
        switch platform.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "appletvos", "tvos", "atv9", "apple tv": return "appletv"
        case "xros", "visionos", "apple vision": return "visionpro"
        case "ipad", "ipados": return "ipad"
        case "osx", "macos", "mac": return "macbook"
        case "ios", "iphoneos", "iphone": return "iphone"
        default: return "shippingbox"
        }
    }

    static func displayName(for platform: String) -> String {
        switch platform.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "appletvos", "tvos", "atv9", "apple tv": return "Apple TV"
        case "xros", "visionos", "apple vision": return "visionOS"
        case "ipad", "ipados": return "iPad"
        case "osx", "macos", "mac": return "Mac"
        case "ios", "iphoneos", "iphone": return "iOS"
        default: return platform
        }
    }

    var body: some View {
        Image(systemName: Self.symbol(for: platform))
            .font(.system(size: size, weight: .medium))
            .foregroundStyle(.secondary)
            .accessibilityLabel(Self.displayName(for: platform))
    }
}

/// Pure-Swift coordinate & phase math for window-synchronized skeleton shimmer.
enum ShimmerLayoutMath {
    static let period: CFTimeInterval = 1.45
    static let sweepFraction: Double = 0.72

    /// Aligns every mounted shimmer layer to a single wall-clock phase so rows
    /// appearing at different times sweep as one continuous wave.
    static func beginTime(forWallClock wallClock: CFTimeInterval, layerTime: CFTimeInterval,
                          period: CFTimeInterval = Self.period) -> CFTimeInterval {
        guard period > 0 else { return layerTime }
        var phase = wallClock.truncatingRemainder(dividingBy: period)
        if phase < 0 { phase += period }
        return layerTime - phase
    }

    /// Maps a global horizontal gleam sweep `[ -bandWidth, containerWidth + bandWidth ]`
    /// back into `CAGradientLayer` unit space `[0, 1]` for a subview at `viewFrameInContainer`.
    static func unitSweepEndpoints(viewFrameInContainer: CGRect, containerWidth: CGFloat) -> (
        startFrom: CGPoint, endFrom: CGPoint, startTo: CGPoint, endTo: CGPoint
    ) {
        let viewWidth = max(viewFrameInContainer.width, 1)
        let effectiveContainerWidth = max(containerWidth, viewFrameInContainer.maxX, viewWidth)
        let bandWidth = max(140, effectiveContainerWidth * 0.55)
        func unitX(_ containerX: CGFloat) -> CGFloat {
            (containerX - viewFrameInContainer.minX) / viewWidth
        }
        return (
            startFrom: CGPoint(x: unitX(-bandWidth), y: 0.25),
            endFrom: CGPoint(x: unitX(0), y: 0.75),
            startTo: CGPoint(x: unitX(effectiveContainerWidth), y: 0.25),
            endTo: CGPoint(x: unitX(effectiveContainerWidth + bandWidth), y: 0.75)
        )
    }
}

private final class ShimmerTrackUIView: UIView {
    private static let animationKey = "ipadn.monochrome.shimmer"
    private let gradientLayer = CAGradientLayer()
    private var lastAnimatedWidth: CGFloat = -1
    private var lastAnimatedHeight: CGFloat = -1
    private var lastWindowMinX: CGFloat = .nan
    var isReduceMotionEnabled = false {
        didSet {
            if oldValue != isReduceMotionEnabled { syncAnimation(force: true) }
        }
    }
    var isDarkAppearance = false {
        didSet {
            if oldValue != isDarkAppearance { updatePalette() }
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        backgroundColor = .clear
        gradientLayer.type = .axial
        gradientLayer.locations = [0, 0.5, 1]
        gradientLayer.opacity = 0
        layer.addSublayer(gradientLayer)
        updatePalette()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { nil }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil {
            teardown()
        } else {
            syncAnimation(force: true)
        }
    }

    func teardown() {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientLayer.removeAnimation(forKey: Self.animationKey)
        gradientLayer.opacity = 0
        CATransaction.commit()
        lastAnimatedWidth = -1
        lastAnimatedHeight = -1
        lastWindowMinX = .nan
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientLayer.frame = bounds
        CATransaction.commit()
        syncAnimation(force: false)
    }

    private func updatePalette() {
        // Masked by skeleton bone shapes (~12% light / ~24% dark alpha), so this
        // translucent gleam lifts/deepens only by ~6-10% luminance without color shift.
        let dark = isDarkAppearance || traitCollection.userInterfaceStyle == .dark
        let sheen: UIColor = dark
            ? UIColor.white.withAlphaComponent(0.42)
            : UIColor.black.withAlphaComponent(0.55)
        let edge = sheen.withAlphaComponent(0)
        gradientLayer.colors = [edge.cgColor, sheen.cgColor, edge.cgColor]
    }

    private func syncAnimation(force: Bool) {
        guard let window, !isReduceMotionEnabled, !UIAccessibility.isReduceMotionEnabled,
              bounds.width.isFinite, bounds.height.isFinite,
              bounds.width > 1, bounds.height > 1,
              window.bounds.width.isFinite, window.bounds.width > 1 else {
            teardown()
            return
        }
        let frameInWindow = convert(bounds, to: window)
        guard frameInWindow.minX.isFinite, frameInWindow.width.isFinite else {
            teardown()
            return
        }
        let roundedX = frameInWindow.minX.rounded()
        if !force,
           abs(bounds.width - lastAnimatedWidth) < 0.5,
           abs(bounds.height - lastAnimatedHeight) < 0.5,
           roundedX == lastWindowMinX,
           gradientLayer.animation(forKey: Self.animationKey) != nil {
            return
        }
        lastAnimatedWidth = bounds.width
        lastAnimatedHeight = bounds.height
        lastWindowMinX = roundedX

        let endpoints = ShimmerLayoutMath.unitSweepEndpoints(
            viewFrameInContainer: frameInWindow,
            containerWidth: window.bounds.width
        )
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientLayer.startPoint = endpoints.startTo
        gradientLayer.endPoint = endpoints.endTo
        gradientLayer.opacity = 1
        CATransaction.commit()

        let keyTimes: [NSNumber] = [0, NSNumber(value: ShimmerLayoutMath.sweepFraction), 1]
        let timingFunctions = [
            CAMediaTimingFunction(name: .easeInEaseOut),
            CAMediaTimingFunction(name: .linear),
        ]

        let startAnim = CAKeyframeAnimation(keyPath: "startPoint")
        startAnim.values = [endpoints.startFrom, endpoints.startTo, endpoints.startTo]
        startAnim.keyTimes = keyTimes
        startAnim.timingFunctions = timingFunctions

        let endAnim = CAKeyframeAnimation(keyPath: "endPoint")
        endAnim.values = [endpoints.endFrom, endpoints.endTo, endpoints.endTo]
        endAnim.keyTimes = keyTimes
        endAnim.timingFunctions = timingFunctions

        let group = CAAnimationGroup()
        group.animations = [startAnim, endAnim]
        group.duration = ShimmerLayoutMath.period
        group.repeatCount = .infinity
        group.isRemovedOnCompletion = false
        group.fillMode = .both
        let wallNow = CACurrentMediaTime()
        let layerNow = gradientLayer.convertTime(wallNow, from: nil)
        group.beginTime = ShimmerLayoutMath.beginTime(forWallClock: wallNow, layerTime: layerNow)
        if #available(iOS 15.0, *) {
            group.preferredFrameRateRange = CAFrameRateRange(minimum: 60, maximum: 120, preferred: 120)
        }
        gradientLayer.removeAnimation(forKey: Self.animationKey)
        gradientLayer.add(group, forKey: Self.animationKey)
    }
}

private struct MonochromeShimmerOverlay: UIViewRepresentable {
    let reduceMotion: Bool
    let isDark: Bool
    func makeUIView(context: Context) -> ShimmerTrackUIView {
        let view = ShimmerTrackUIView()
        view.isReduceMotionEnabled = reduceMotion
        view.isDarkAppearance = isDark
        return view
    }
    func updateUIView(_ view: ShimmerTrackUIView, context: Context) {
        view.isReduceMotionEnabled = reduceMotion
        view.isDarkAppearance = isDark
    }
    static func dismantleUIView(_ view: ShimmerTrackUIView, coordinator: ()) {
        view.teardown()
    }
}

private struct MonochromeShimmerModifier: ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme
    func body(content: Content) -> some View {
        if reduceMotion {
            content
        } else {
            content.overlay {
                MonochromeShimmerOverlay(reduceMotion: reduceMotion, isDark: colorScheme == .dark)
                    .allowsHitTesting(false)
                    .mask { content }
            }
        }
    }
}

extension View {
    /// Sweeps a synchronized, 120Hz GPU-driven monochrome gleam across placeholder shapes.
    func monochromeShimmer() -> some View {
        modifier(MonochromeShimmerModifier())
    }
}

struct AppSkeleton: View {
    var body: some View {
        HStack(spacing: 14) {
            RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.tertiarySystemFill)).frame(width: 64, height: 64)
            VStack(alignment: .leading, spacing: 10) {
                RoundedRectangle(cornerRadius: 4).fill(Color(.tertiarySystemFill)).frame(width: 150, height: 13)
                RoundedRectangle(cornerRadius: 4).fill(Color(.quaternarySystemFill)).frame(width: 100, height: 10)
            }
            Spacer()
            Capsule().fill(Color(.tertiarySystemFill)).frame(width: 74, height: 30)
        }
        .monochromeShimmer()
        .padding(.vertical, 6)
        .accessibilityHidden(true)
    }
}

/// One cell of the App Store product page's horizontal info strip.
struct InfoStripItem: View {
    let caption: LocalizedStringKey
    /// Store data (version, size, category): already in its final language.
    let value: String
    var detail: String? = nil
    var symbol: String? = nil
    var body: some View {
        VStack(spacing: 4) {
            Text(caption).font(.caption2.weight(.semibold)).foregroundStyle(.secondary).lineLimit(1)
            Group {
                if let symbol {
                    Image(systemName: symbol).font(.title3.weight(.semibold))
                } else {
                    Text(value).font(.title3.weight(.bold)).lineLimit(1).minimumScaleFactor(0.6)
                }
            }
            .foregroundStyle(.secondary)
            .frame(height: 26)
            Text(detail ?? (symbol == nil ? " " : value)).font(.caption).foregroundStyle(.secondary)
                .lineLimit(1).minimumScaleFactor(0.8)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 4)
        .accessibilityElement(children: .combine)
    }
}

/// Six separate digit boxes like Apple's two-factor screen. Backed by one
/// hidden one-time-code field so paste and SMS/AutoFill keep working.
struct VerificationCodeField: View {
    @Binding var code: String
    var length = 6
    var disabled = false
    var onComplete: (String) -> Void
    @FocusState private var focused: Bool
    var body: some View {
        ZStack {
            TextField("", text: $code)
                .keyboardType(.numberPad)
                .textContentType(.oneTimeCode)
                .focused($focused)
                .disabled(disabled)
                .foregroundStyle(.clear).tint(.clear)
                .frame(width: 1, height: 1).opacity(0.02)
                .accessibilityIdentifier("apple.verification.code")
                .compatibleOnChange(of: code) { value in
                    let digits = String(value.filter { $0.isASCII && $0.isNumber }.prefix(length))
                    if digits != value { code = digits; return }
                    if digits.count == length { onComplete(digits) }
                }
            HStack(spacing: 10) {
                ForEach(0..<length, id: \.self) { index in
                    let characters = Array(code)
                    let current = index == characters.count && focused
                    Text(index < characters.count ? String(characters[index]) : "")
                        .font(.title.monospacedDigit().weight(.semibold))
                        .frame(width: 44, height: 56)
                        .background(Color(.secondarySystemGroupedBackground),
                                    in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .stroke(current ? UX.tint : Color(.separator), lineWidth: current ? 2 : 0.5))
                }
            }
            .environment(\.layoutDirection, .leftToRight)
            .contentShape(Rectangle())
            .onTapGesture { focused = true }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("验证码，已输入 \(code.count) 位")
        }
        .onAppear { if !disabled { focused = true } }
        .compatibleOnChange(of: disabled) { value in if !value { focused = true } }
    }
}

struct ToolPageStyle: ViewModifier {
    func body(content: Content) -> some View {
        content.listStyle(.insetGrouped).compatHideScrollContentBackground()
            .background(Color(.systemGroupedBackground)).compatInteractiveKeyboardDismissal()
            .compatibleListSectionSpacing(20)
            .compatibleVerticalContentMargin(.bottom, 20)
    }
}
extension View { func toolPage() -> some View { modifier(ToolPageStyle()) } }

/// One line of text that, when it does not fit, scrolls once in place to
/// reveal the rest and returns, instead of being cut off with an ellipsis.
struct MarqueeText: View {
    let text: String
    var font: Font = .subheadline
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var textWidth: CGFloat = 0
    @State private var boxWidth: CGFloat = 0
    @State private var offset: CGFloat = 0
    private var overflow: CGFloat { max(0, textWidth - boxWidth) }
    var body: some View {
        // The hidden copy sets the line height and takes the available width.
        Text(text).font(font).lineLimit(1).hidden()
            .frame(maxWidth: .infinity, alignment: .leading)
            .overlay(alignment: .leading) {
                Text(text).font(font).lineLimit(1).fixedSize()
                    .offset(x: offset)
                    .compatibleOnGeometryChange(for: CGFloat.self) { $0.size.width } action: { nextWidth in
                        if abs(textWidth - nextWidth) > 0.5 { textWidth = nextWidth }
                    }
            }
            .compatibleOnGeometryChange(for: CGFloat.self) { $0.size.width } action: { nextWidth in
                if abs(boxWidth - nextWidth) > 0.5 { boxWidth = nextWidth }
            }
            .clipped()
            .mask {
                HStack(spacing: 0) {
                    Rectangle()
                    if overflow > 0 {
                        LinearGradient(colors: [.black, .clear], startPoint: .leading, endPoint: .trailing).frame(width: 14)
                    }
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
            .accessibilityAddTraits(.isStaticText)
            .task(id: overflow) {
                offset = 0
                guard overflow > 1, !reduceMotion else { return }
                do {
                    try await compatSleep(milliseconds: Double(900))
                    withAnimation(.easeInOut(duration: max(0.8, Double(overflow) / 35))) { offset = -overflow - 14 }
                    try await compatSleep(milliseconds: Double(Int(max(0.8, Double(overflow) / 35) * 1000) + 1200))
                    withAnimation(.easeInOut(duration: 0.45)) { offset = 0 }
                } catch { offset = 0 }
            }
    }
}

extension AnyTransition {
    /// Replaces a status label or button without the old and new content
    /// being visible at the same time: the old one fades out quickly, then
    /// the new one fades and scales in.
    static var statusSwap: AnyTransition {
        .asymmetric(
            insertion: .opacity.combined(with: .offset(y: 4))
                .animation(.easeOut(duration: 0.18).delay(0.06)),
            removal: .opacity.combined(with: .offset(y: -3))
                .animation(.easeIn(duration: 0.10)))
    }

    static func statusSwap(reduceMotion: Bool) -> AnyTransition {
        reduceMotion ? .opacity : statusSwap
    }
}

extension Animation {
    static var compatibleSnappy: Animation {
        if #available(iOS 17, *) { return .snappy }
        return compatibleSnappy(duration: 0.5)
    }
    static func compatibleSnappy(duration: Double) -> Animation {
        if #available(iOS 17, *) { return .snappy(duration: duration) }
        return .spring(response: duration, dampingFraction: 0.85)
    }
}

extension View {
    @ViewBuilder func compatibleSymbolReplacement() -> some View {
        if #available(iOS 17, *) { contentTransition(.symbolEffect(.replace)) }
        else { compatContentTransitionOpacity() }
    }
    @ViewBuilder func compatibleSelectionFeedback<T: Equatable>(trigger: T) -> some View {
        if #available(iOS 17, *) { sensoryFeedback(.selection, trigger: trigger) }
        else { onChange(of: trigger) { _ in UX.feedback() } }
    }
    @ViewBuilder func compatiblePresentationCornerRadius(_ radius: CGFloat) -> some View {
        if #available(iOS 26, *) {
            // iOS 26 Liquid Glass floating sheets automatically compute display-concentric
            // corner radii; overriding with a small fixed radius breaks concentricity.
            self
        } else if #available(iOS 16.4, *) {
            presentationCornerRadius(radius)
        } else {
            self
        }
    }
    @ViewBuilder func compatibleListSectionSpacing(_ spacing: CGFloat) -> some View {
        if #available(iOS 17, *) { listSectionSpacing(spacing) }
        else { self }
    }
    @ViewBuilder func compatibleVerticalContentMargin(_ edge: Edge.Set, _ length: CGFloat) -> some View {
        if #available(iOS 17, *) { contentMargins(edge, length, for: .scrollContent) }
        else if edge == .bottom {
            safeAreaInset(edge: .bottom, spacing: 0) { Color.clear.frame(height: length).allowsHitTesting(false) }
        } else { self }
    }
    @ViewBuilder func compatibleScrollTargetLayout() -> some View {
        if #available(iOS 17, *) { scrollTargetLayout() }
        else { self }
    }
    @ViewBuilder func compatibleViewAlignedScrolling() -> some View {
        if #available(iOS 17, *) { scrollTargetBehavior(.viewAligned) }
        else { self }
    }
}

/// The reveal animation needs independently animated top and bottom radii.
/// Uses UIKit continuous-corner paths directly instead of `UnevenRoundedRectangle`
/// so builds compiled with newer iOS SDKs never emit strong `UnevenRoundedRectangle`
/// fixups that break early iOS 16 launches.
struct CompatibleCardShape: Shape {
    var top: CGFloat
    var bottom: CGFloat
    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get { AnimatablePair(top, bottom) }
        set { top = newValue.first; bottom = newValue.second }
    }
    func path(in rect: CGRect) -> Path {
        guard rect.width > 0, rect.height > 0 else { return Path() }
        let limit = max(0, min(rect.width, rect.height) / 2)
        let t = min(max(0, top), limit), b = min(max(0, bottom), limit)
        if abs(t - b) < 0.01 {
            return Path(UIBezierPath(roundedRect: rect, cornerRadius: t).cgPath)
        }
        if b < 0.01 {
            return Path(UIBezierPath(
                roundedRect: rect,
                byRoundingCorners: [.topLeft, .topRight],
                cornerRadii: CGSize(width: t, height: t)
            ).cgPath)
        }
        if t < 0.01 {
            return Path(UIBezierPath(
                roundedRect: rect,
                byRoundingCorners: [.bottomLeft, .bottomRight],
                cornerRadii: CGSize(width: b, height: b)
            ).cgPath)
        }
        var path = Path()
        path.move(to: CGPoint(x: rect.minX + t, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX - t, y: rect.minY))
        path.addArc(center: CGPoint(x: rect.maxX - t, y: rect.minY + t), radius: t,
                    startAngle: .degrees(-90), endAngle: .degrees(0), clockwise: false)
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - b))
        path.addArc(center: CGPoint(x: rect.maxX - b, y: rect.maxY - b), radius: b,
                    startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
        path.addLine(to: CGPoint(x: rect.minX + b, y: rect.maxY))
        path.addArc(center: CGPoint(x: rect.minX + b, y: rect.maxY - b), radius: b,
                    startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + t))
        path.addArc(center: CGPoint(x: rect.minX + t, y: rect.minY + t), radius: t,
                    startAngle: .degrees(180), endAngle: .degrees(270), clockwise: false)
        path.closeSubpath()
        return path
    }
}

private struct GeometryObserver<Value: Equatable>: View {
    let value: Value
    let action: (Value) -> Void
    var body: some View {
        Color.clear
            .onAppear { action(value) }
            .compatibleOnChange(of: value) { next in action(next) }
    }
}

extension ToolbarItemPlacement {
    static var compatibleTopBarLeading: Self {
        if #available(iOS 17, *) { return .topBarLeading }
        return .navigationBarLeading
    }

    static var compatibleTopBarTrailing: Self {
        if #available(iOS 17, *) { return .topBarTrailing }
        return .navigationBarTrailing
    }
}

extension View {
    /// Observes a derived geometry value using `GeometryReader` + `onChange`, avoiding
    /// SwiftUI's backported `_GeometryActionModifier` strong link symbols on iOS 16
    /// and nonisolated layout-pass callbacks on Swift 6 / iOS 27.2 beta.
    func compatibleOnGeometryChange<T: Equatable>(
        for type: T.Type,
        of transform: @escaping (GeometryProxy) -> T,
        action: @escaping (T) -> Void
    ) -> some View {
        background(
            GeometryReader { proxy in
                GeometryObserver(value: transform(proxy), action: action)
            }
            .allowsHitTesting(false)
        )
    }

    @ViewBuilder func compatibleOnChange<Value: Equatable>(of value: Value, perform action: @escaping (Value) -> Void) -> some View {
        if #available(iOS 17, *) { onChange(of: value) { _, newValue in action(newValue) } }
        else { onChange(of: value, perform: action) }
    }

    @ViewBuilder func compatibleNavigationDestination<Item: Hashable, Destination: View>(
        item: Binding<Item?>, @ViewBuilder destination: @escaping (Item) -> Destination
    ) -> some View {
        if #available(iOS 17.0, *) {
            navigationDestination(item: item, destination: destination)
        } else {
            compatNavigationDestination(isPresented: Binding(
                get: { item.wrappedValue != nil },
                set: { if !$0 { item.wrappedValue = nil } }
            )) {
                if let value = item.wrappedValue { destination(value) }
            }
        }
    }

    @ViewBuilder func compatibleInteractionShape<S: Shape>(_ shape: S) -> some View {
        if #available(iOS 17, *) { contentShape([.interaction, .accessibility], shape) }
        else { contentShape(.interaction, shape) }
    }

    @ViewBuilder func compatibleScrollBounce() -> some View {
        if #available(iOS 16.4, *) { scrollBounceBehavior(.basedOnSize) }
        else { self }
    }

    /// Digits roll down as a countdown ticks, like Telegram's undo timer.
    @ViewBuilder func compatibleCountdownTransition() -> some View {
        if #available(iOS 17, *) { contentTransition(.numericText(countsDown: true)) }
        else { compatNumericTextTransition() }
    }

    @ViewBuilder func compatibleNumericTransition() -> some View {
        compatNumericTextTransition()
    }

    @ViewBuilder func compatibleBounce(trigger: some Equatable) -> some View {
        if #available(iOS 17, *) { symbolEffect(.bounce, value: trigger) }
        else { self }
    }

    @ViewBuilder func compatibleHorizontalScrollMargins(_ margin: CGFloat) -> some View {
        if #available(iOS 17, *) { contentMargins(.horizontal, margin, for: .scrollContent) }
        else { self }
    }

    @ViewBuilder func legacyHorizontalPadding(_ margin: CGFloat) -> some View {
        if #available(iOS 17, *) { self }
        else { padding(.horizontal, margin) }
    }
}

/// Places views left to right and wraps to a new line when one doesn't fit,
/// like tags (recent searches). iOS 16+ only; the one call site falls back to
/// a horizontal scroller on iOS 15.
@available(iOS 16.0, *)
struct ChipFlow: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? .infinity
        let rows = arrange(subviews, width: width)
        let height = rows.reduce(0) { $0 + $1.height } + spacing * CGFloat(max(0, rows.count - 1))
        return CGSize(width: proposal.width ?? rows.map(\.width).max() ?? 0, height: height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var y = bounds.minY
        for row in arrange(subviews, width: bounds.width) {
            var x = bounds.minX
            for index in row.indices {
                let size = subviews[index].sizeThatFits(ProposedViewSize(width: bounds.width, height: nil))
                subviews[index].place(at: CGPoint(x: x, y: y + (row.height - size.height) / 2), proposal: ProposedViewSize(size))
                x += size.width + spacing
            }
            y += row.height + spacing
        }
    }

    private struct Row { var indices: [Int] = []; var width: CGFloat = 0; var height: CGFloat = 0 }

    private func arrange(_ subviews: Subviews, width: CGFloat) -> [Row] {
        var rows: [Row] = []
        var current = Row()
        for index in subviews.indices {
            let size = subviews[index].sizeThatFits(ProposedViewSize(width: width, height: nil))
            let needed = current.indices.isEmpty ? size.width : current.width + spacing + size.width
            if needed > width, !current.indices.isEmpty {
                rows.append(current); current = Row()
            }
            current.width = current.indices.isEmpty ? size.width : current.width + spacing + size.width
            current.height = max(current.height, size.height)
            current.indices.append(index)
        }
        if !current.indices.isEmpty { rows.append(current) }
        return rows
    }
}

/// A capsule chip whose long-press menu lifts only the chip, keeping its round
/// ends. SwiftUI's own context menu inside a List lifts the whole row as a
/// square-cornered rectangle, so the menu comes from UIKit here.
struct MenuChip: UIViewRepresentable {
    let title: String
    let symbol: String
    let identifier: String
    let deleteTitle: String
    let onTap: () -> Void
    let onDelete: () -> Void

    struct Label: View {
        let title: String
        let symbol: String
        var pressed = false
        @Environment(\.accessibilityReduceMotion) private var reduceMotion
        var body: some View {
            HStack(spacing: 6) {
                Image(systemName: symbol).font(.footnote.weight(.medium)).foregroundStyle(.secondary)
                Text(verbatim: title).font(.subheadline).foregroundStyle(.primary).lineLimit(1)
            }
            .padding(.horizontal, 14).frame(minHeight: 38)
            .background(Color(.secondarySystemGroupedBackground), in: Capsule())
            .opacity(pressed ? 0.72 : 1)
            .scaleEffect(pressed && !reduceMotion ? 0.94 : 1)
            .animation(reduceMotion ? nil : .compatibleSnappy(duration: 0.14), value: pressed)
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> TactileContainerView {
        let host = UIHostingController(rootView: Label(title: title, symbol: symbol))
        host.view.backgroundColor = .clear
        host.view.isUserInteractionEnabled = false
        host.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        context.coordinator.host = host
        let view = TactileContainerView()
        view.backgroundColor = .clear
        view.onPressChange = { [weak coordinator = context.coordinator] down in
            coordinator?.setPressed(down)
        }
        host.view.frame = view.bounds
        view.addSubview(host.view)
        view.addInteraction(UIContextMenuInteraction(delegate: context.coordinator))
        view.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped)))
        view.isAccessibilityElement = true
        view.accessibilityTraits = .button
        update(view, context: context)
        return view
    }

    func updateUIView(_ view: TactileContainerView, context: Context) {
        context.coordinator.chip = self
        context.coordinator.host?.rootView = Label(title: title, symbol: symbol, pressed: context.coordinator.pressed)
        update(view, context: context)
    }

    private func update(_ view: UIView, context: Context) {
        view.accessibilityLabel = title
        view.accessibilityIdentifier = identifier
        let coordinator = context.coordinator
        view.accessibilityCustomActions = [UIAccessibilityCustomAction(name: deleteTitle) { _ in
            coordinator.chip.onDelete(); return true
        }]
    }

    @available(iOS 16.0, *)
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: TactileContainerView, context: Context) -> CGSize? {
        context.coordinator.host?.sizeThatFits(in: CGSize(width: proposal.width ?? .greatestFiniteMagnitude,
                                                          height: .greatestFiniteMagnitude))
    }

    final class Coordinator: NSObject, UIContextMenuInteractionDelegate {
        var chip: MenuChip
        var host: UIHostingController<Label>?
        var pressed = false
        init(_ chip: MenuChip) { self.chip = chip }

        func setPressed(_ down: Bool) {
            guard pressed != down else { return }
            pressed = down
            host?.rootView = Label(title: chip.title, symbol: chip.symbol, pressed: down)
        }

        @objc func tapped() {
            setPressed(false)
            UX.tapSoft()
            chip.onTap()
        }

        func contextMenuInteraction(_ interaction: UIContextMenuInteraction,
                                    configurationForMenuAtLocation location: CGPoint) -> UIContextMenuConfiguration? {
            UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
                guard let self else { return nil }
                return UIMenu(children: [
                    UIAction(title: self.chip.deleteTitle, image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                        self?.chip.onDelete()
                    },
                ])
            }
        }

        func contextMenuInteraction(_ interaction: UIContextMenuInteraction,
                                    previewForHighlightingMenuWithConfiguration configuration: UIContextMenuConfiguration) -> UITargetedPreview? {
            UIView.performWithoutAnimation { setPressed(false) }
            return preview(interaction)
        }

        func contextMenuInteraction(_ interaction: UIContextMenuInteraction,
                                    previewForDismissingMenuWithConfiguration configuration: UIContextMenuConfiguration) -> UITargetedPreview? {
            preview(interaction)
        }

        func contextMenuInteraction(_ interaction: UIContextMenuInteraction,
                                    willDisplayMenuFor configuration: UIContextMenuConfiguration,
                                    animator: (any UIContextMenuInteractionAnimating)?) {
            setPressed(false)
        }

        private func preview(_ interaction: UIContextMenuInteraction) -> UITargetedPreview? {
            guard let view = interaction.view, let window = view.window else { return nil }
            let parameters = UIPreviewParameters()
            parameters.backgroundColor = .clear
            parameters.visiblePath = UIBezierPath(roundedRect: view.bounds, cornerRadius: view.bounds.height / 2)
            // No drop shadow around the lifted chip.
            parameters.shadowPath = UIBezierPath()
            // Lift it in the window: the list cell clips the enlarged chip at its edge.
            let center = view.convert(CGPoint(x: view.bounds.midX, y: view.bounds.midY), to: window)
            return UITargetedPreview(view: view, parameters: parameters, target: UIPreviewTarget(container: window, center: center))
        }
    }
}

/// `MenuChip` sizes itself through `UIViewRepresentable.sizeThatFits`, which is
/// iOS 16-only; without it the representable measures as zero on iOS 15 and the
/// recent-search chips disappear. Use a plain SwiftUI capsule there.
struct CompatMenuChip: View {
    let title: String
    let symbol: String
    let identifier: String
    let deleteTitle: String
    let onTap: () -> Void
    let onDelete: () -> Void

    var body: some View {
        if #available(iOS 16.0, *) {
            MenuChip(title: title, symbol: symbol, identifier: identifier,
                     deleteTitle: deleteTitle, onTap: onTap, onDelete: onDelete)
        } else {
            Button(action: onTap) {
                MenuChip.Label(title: title, symbol: symbol)
            }
            .buttonStyle(.plain)
            .contextMenu {
                Button(role: .destructive, action: onDelete) {
                    Label(deleteTitle, systemImage: "trash")
                }
            }
            .accessibilityIdentifier(identifier)
        }
    }
}
